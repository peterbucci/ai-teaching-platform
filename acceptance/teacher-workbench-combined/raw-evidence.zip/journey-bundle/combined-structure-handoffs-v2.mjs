/** Four bounded read-only combined-candidate checks. Run after the current guard owner releases. */
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {openRuntime,hash} from './read-only-runtime.mjs';
const [stateArg,outArg,playwrightArg,safetyArg]=process.argv.slice(2);
const h=await openRuntime({stateArg,outArg,playwrightArg,safetyArg,helper:'combined-structure-handoffs'});
h.report.helperSha256=hash(readFileSync(new URL(import.meta.url)));
h.report.category='R04 and R06 functional handoffs; selected original records; fictional cloned data; no saves, generation, approval, delivery or recipient selection';
h.report.requestedChecks=['R04-decision','R04-assignment','R04-resume','R06-prepare'];
const knownLesson='2a18db3f-a6dc-4f61-b96d-f50647d574ad';
const concern='/teacher/insights?assignment=30000000-0000-4000-8000-000000000001&origin=synthetic_fixture&concept=transmission_delay&misconception=transmission_depends_on_distance&view=concerns&returnTo=patterns&workspacePane=main#patterns';
const exact=async(page,url,keys)=>{const actual=new URL(page.url());assert.equal(actual.pathname,url.pathname);for(const key of keys)assert.deepEqual(actual.searchParams.getAll(key),url.searchParams.getAll(key),'Context changed: '+key);};
try{
 const {page,context}=await h.launch('teacher');
 h.report.browserErrors=[];page.on('pageerror',error=>h.report.browserErrors.push({url:page.url(),message:error.message}));
 const home=async()=>{const r=await page.goto(h.manifest.origin+'/teacher');assert.equal(r.status(),200);await page.locator('.ov-workspace').waitFor();};
 await h.run('R04-decision','Overview decision opens its exact saved original evidence',page,async()=>{
   await home();const candidates=page.locator('section[aria-labelledby="ov-decision"] .ov-priority a[href*="/teacher/evidence"][href*="attempt="][href*="session="]');
   assert.ok(await candidates.count(),'No exact-record decision link in current fixture; do not substitute recent activity');
   const link=candidates.first(),url=new URL(await link.getAttribute('href'),h.manifest.origin);
   const sessionId=url.searchParams.get('session'),attemptId=url.searchParams.get('attempt'),evaluationId=url.searchParams.get('evaluation');
   assert.ok(sessionId&&attemptId);const before=await h.get(context,'/api/teacher/sessions/'+sessionId);
   assert.equal(before.session.assignment_id,url.searchParams.get('assignment'));
   const original=before.attempts.find(a=>a.id===attemptId);assert.ok(original?.submitted_at);
   if(evaluationId)assert.ok(before.evaluations.some(e=>e.id===evaluationId&&e.attempt_id===attemptId));
   await link.click();await page.locator('.wb-original-response').waitFor();
   await exact(page,url,['assignment','origin','concept','returnTo','session','attempt','evaluation']);
   assert.equal(await page.locator('.wb-original-response').textContent(),original.response_text);
   assert.equal(await page.getByRole('heading',{name:'Original question',exact:true}).locator('+ p.wb-original').textContent(),original.question.prompt_text);
   assert.deepEqual(await h.get(context,'/api/teacher/sessions/'+sessionId),before);
   h.check('R04-decision','Exact displayed original and authorized session preserved',true,{href:url.href,sessionId,attemptId,evaluationId,sourceRef:original.question.content_ref});await h.capture(page,'r04-decision-evidence');
 });
 await h.run('R04-assignment','Whole-course assignment rail opens its authorized assignment',page,async()=>{
   await home();const links=page.locator('.ov-assignment-list .ov-assignment-title');assert.ok(await links.count()>0);
   const link=links.first(),title=(await link.innerText()).trim(),url=new URL(await link.getAttribute('href'),h.manifest.origin),id=url.searchParams.get('assignment');assert.ok(id);
   const before=await h.get(context,'/api/teacher/assignments/'+id+'/metrics?origin='+encodeURIComponent(url.searchParams.get('origin')??'all'));assert.equal(before.assignment_id,id);
   await link.click();await page.locator('.awa-assignment-workspace').waitFor();await exact(page,url,['assignment','origin','returnTo']);
   assert.ok((await page.locator('.awa-page-heading .awa-eyebrow').textContent()).includes(title));
   h.check('R04-assignment','Rail assignment identity and displayed title agree',true,{href:url.href,assignmentId:id,classId:before.class_id,title});await h.capture(page,'r04-assignment');
 });
 await h.run('R04-resume','Resume existing lesson and private intervention without writes',page,async()=>{
   const opened=[];await home();
   const lessonLink=page.locator('#ov-resume a[href*="'+knownLesson+'"]');
   assert.equal(await lessonLink.count(),1,'Exact inherited unfinished lesson must remain discoverable');
   const lessonUrl=new URL(await lessonLink.getAttribute('href'),h.manifest.origin),lessonBefore=await h.get(context,'/api/teacher/objectives/'+knownLesson);
   assert.equal(lessonBefore.lesson.id,knownLesson);await lessonLink.click();await page.locator('.aw-workspace').waitFor();
   await exact(page,lessonUrl,['step']);assert.ok(lessonUrl.pathname.includes(knownLesson));
   assert.equal((await page.locator('.aw-lesson-identity h1').innerText()).trim(),lessonBefore.lesson.title);
   assert.deepEqual(await h.get(context,'/api/teacher/objectives/'+knownLesson),lessonBefore);opened.push({kind:'lesson',id:knownLesson,href:lessonUrl.href,revision:lessonBefore.lesson.revision});await h.capture(page,'r04-resume-lesson');
   await home();const interventionLink=page.locator('#ov-resume a[href*="/teacher/interventions"][href*="draft="]').first();
   assert.equal(await interventionLink.count(),1,'No saved private intervention is available; do not generate a substitute');
   const url=new URL(await interventionLink.getAttribute('href'),h.manifest.origin),id=url.searchParams.get('draft'),before=await h.get(context,'/api/teacher/interventions/'+id);
   assert.equal(before.draft.id,id);assert.equal(before.draft.status,'private_draft');assert.equal(before.approval,null);assert.equal(before.delivery,null);
   await interventionLink.click();await page.locator('#intervention-draft-title').waitFor();await exact(page,url,['assignment','draft']);
   assert.equal(await page.locator('#intervention-draft-title').getAttribute('aria-label'),'Activity: '+before.draft.activity.title);
   assert.deepEqual(await h.get(context,'/api/teacher/interventions/'+id),before);opened.push({kind:'private intervention',id,href:url.href,revision:before.draft.revision});
   h.check('R04-resume','Both exact saved drafts opened; snapshots unchanged',true,{opened});await h.capture(page,'r04-resume-intervention');
 });
 await h.run('R06-prepare','Populated concern hands bounded selected evidence to private preparation',page,async()=>{
   const r=await page.goto(h.manifest.origin+concern);assert.equal(r.status(),200);await page.locator('.ci-record .ci-counts').waitFor();
   const link=page.locator('.ci-record .ci-actions').getByRole('link',{name:'Prepare an intervention →',exact:true});assert.equal(await link.count(),1,'Current populated concern cannot offer preparation');
   const url=new URL(await link.getAttribute('href'),h.manifest.origin),seeds=url.searchParams.getAll('seedAttempt');
   assert.equal(url.pathname,'/teacher/interventions');assert.ok(seeds.length>0&&seeds.length<=60);assert.equal(new Set(seeds).size,seeds.length);
   for(const key of ['assignment','origin','concept','misconception','returnTo'])assert.equal(url.searchParams.get(key),new URL(h.manifest.origin+concern).searchParams.get(key));
   assert.equal(url.searchParams.has('draft'),false);await link.click();await page.getByRole('heading',{name:'Evidence used',exact:true}).waitFor();
   await exact(page,url,['assignment','origin','concept','misconception','returnTo','seedAttempt']);
   const rows=await page.locator('.lp-intervention-evidence').evaluateAll(nodes=>nodes.map(node=>({attemptId:node.id.replace(/^evidence-/,''),selected:node.querySelector('input[type="checkbox"]')?.checked??false})));
   assert.ok(rows.length>=seeds.length&&rows.length<=60);assert.deepEqual(rows.filter(r=>r.selected).map(r=>r.attemptId).sort(),[...seeds].sort());
   const generation=page.getByRole('button',{name:'Generate private draft',exact:true});assert.equal(await generation.count(),1);assert.equal(await generation.isEnabled(),true);
   assert.equal(await page.getByRole('heading',{name:'Prepare a review activity',exact:true}).count(),1);
   const sourceDetails=page.locator('.lp-intervention-scope-details');await sourceDetails.locator('summary').click();const sourceText=await sourceDetails.innerText();assert.ok(sourceText.includes('Lesson version:')&&sourceText.includes('Source:'));
   const back=page.getByRole('link',{name:'Back to investigation',exact:true});assert.equal(await back.count(),1);const backUrl=new URL(await back.getAttribute('href'),h.manifest.origin);
   for(const key of ['assignment','origin','concept','misconception','returnTo'])assert.equal(backUrl.searchParams.get(key),url.searchParams.get(key));
   h.check('R06-prepare','Bounded checked evidence and scope retained; generation never invoked',true,{href:url.href,seeds,previewRows:rows,sourceText,returnHref:backUrl.href,generationInvoked:false,recipientsSelected:false});await h.capture(page,'r06-evidence-preview');
 });
 if(h.report.browserErrors.length)h.check('BROWSER','No page errors',false,{errors:h.report.browserErrors});
}catch(error){h.check('FATAL','Structure handoff setup',false,{error:error.message});}finally{await h.finish();}
