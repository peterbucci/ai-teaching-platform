/** Provider-disabled browser continuation. See INTERVENTION_CONTINUATION.md.
 * Usage: <resume-delivered> <state> <seam-json> <fresh-output> <playwright-package> <reviewed-safety.mjs>
 */
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { createRequire } from "node:module";
import { existsSync, readFileSync } from "node:fs";
import { mkdir, writeFile } from "node:fs/promises";
import { resolve } from "node:path";
import { pathToFileURL } from "node:url";
const [phase, stateArg, seamArg, outArg, playwrightArg, safetyArg] =
  process.argv.slice(2);
assert.ok(
  ["resume-delivered"].includes(phase),
);
for (const value of [stateArg, seamArg, outArg, playwrightArg, safetyArg])
  assert.ok(value);
const hash = (value) => createHash("sha256").update(value).digest("hex");
const state = resolve(stateArg),
  out = resolve(outArg);
assert.equal(
  existsSync(out),
  false,
  "Use a fresh output directory; earlier evidence is immutable.",
);
const manifest = JSON.parse(readFileSync(resolve(state, "manifest.json")));
const seamBytes = readFileSync(resolve(seamArg));
const seam = JSON.parse(seamBytes);
const directAuthoring=false;
const preparation=seam.preparation,authoring=preparation.authoring;
assert.equal(hash(seamBytes),"759043e3379d46967a459a27314a907e32cb8be600f220411cbfab81721355c7","Resume only the exact acknowledged-delivery/title-collision receipt");
assert.equal(seam.phase,"review-and-submit");assert.equal(seam.status,"failed");
assert.equal(seam.failure_stage,"same-student-opens-assigned-review");assert.match(seam.error,/strict mode violation/);
assert.equal(seam.lock_retained,false);
assert.deepEqual(seam.mutations.map(m=>[m.action,m.http_status,m.status]),["save","approve","deliver"].map(a=>[a,200,"acknowledged"]));
assert.equal(seam.approval_id,"f187e046-fa5b-4f9d-bb3e-ddd1b457cee6");assert.equal(seam.delivery_id,"91e360b9-7385-4453-a571-6aaf71e6840b");
assert.equal(preparation.draft_id,"7dd12f61-4dbd-46d4-8a57-8381d8a7bb87");assert.equal(preparation.status,"completed");
assert.equal(manifest.sourceSha,"c26664e49b7cc15fa7c63828f5c582c9b8cac2d8");assert.equal(manifest.sourceTree,"333b73e1cae1daddf6edd61300655d0b4825ed67");
assert.equal(manifest.project,"lp-teacher-combined-01a174be");assert.equal(manifest.origin,"http://localhost:3449");assert.equal(manifest.paidModelCallsAuthorized,false);
assert.equal(seam.source_sha,manifest.sourceSha);assert.equal(seam.source_tree,manifest.sourceTree);assert.equal(seam.project,manifest.project);assert.equal(seam.origin,manifest.origin);
assert.equal(authoring.functional_completed_through,"teacher-original-evidence");assert.equal(authoring.student_id,"10000000-0000-4000-8000-000000000002");
const environment = Object.fromEntries(
  readFileSync(resolve(state, ".env.acceptance"), "utf8")
    .trim()
    .split(/\r?\n/)
    .map((line) => {
      const split = line.indexOf("=");
      return [line.slice(0, split), line.slice(split + 1)];
    }),
);
for (const key of ["OPENAI_API_KEY", "OPENAI_MODEL"])
  assert.equal(environment[key]?.trim() || "", "");
assert.equal(environment.AUTH_URL, manifest.origin);
assert.equal(
  hash(readFileSync(resolve(safetyArg))),
  "af01b05dd317682a47b6ec64acc5083cae1430383d697dcb1ede53687722c485",
);
const { acquireLock, preflight, MIN_RUNTIME_GIB, LOCK_PATH } = await import(
  pathToFileURL(resolve(safetyArg)).href
);
assert.ok(
  process.env.BROWSER_EXECUTABLE,
  "Use an isolated installed browser executable.",
);
const { chromium } = createRequire(import.meta.url)(resolve(playwrightArg));
await mkdir(out, { recursive: false });
const report = {
  phase,
  status: "running",
  source_sha: manifest.sourceSha,
  source_tree: manifest.sourceTree,
  project: manifest.project,
  origin: manifest.origin,
  seam_sha256: hash(seamBytes),
  input_kind: directAuthoring
    ? "passed authoring receipt for separate curated activation; no completed intervention seam claimed"
    : "explicit synthetic preparation/evaluation receipt",
  harness_sha256: hash(readFileSync(new URL(import.meta.url))),
  preparation,
  prior_delivery:{report_sha256:hash(seamBytes),action_receipts:seam.mutations,no_mutation_replay:true},
  started_at: new Date().toISOString(),
  checks: [],
  progress: [],
  mutations: [],
  screenshots: [],
  safety: [],
  blocked_off_origin_requests: [],
  blocked_context_writes: [],
  context_checks: [],
  paid_calls: 0,
  actual_model_verification: "unrun",
  screen_reader: "unrun",
  native_200_percent_zoom: "unrun",
  functional_completed_through: null,
};
let release,
  browser,
  teacher,
  student,
  contextReadOnly = false,
  mutationUncertain = false,
  browserCloseUncertain = false,
  stage = "guard";
let allowedStudentAction=null,displayAllowed=true;
const save = () =>
  writeFile(resolve(out, "report.json"), JSON.stringify(report, null, 2));
function guard(before) {
  const observation = preflight({
    source: manifest.source,
    state,
    minimumGiB: MIN_RUNTIME_GIB,
    explicitPath: manifest.dockerDataPath || undefined,
    probeContainer: manifest.storageProbeContainer || undefined,
  });
  report.safety.push({ before, ...observation });
  assert.equal(
    observation.pass,
    true,
    "Shared storage preflight failed; stop without cleanup or restart.",
  );
}
async function bounded(label, operation, observed = () => {}) {
  report.progress.push({
    label,
    status: "waiting",
    at: new Date().toISOString(),
  });
  await save();
  let timer;
  try {
    const result = await Promise.race([
      operation(),
      new Promise((_, reject) => {
        timer = setTimeout(
          () => reject(new Error(label + " exceeded 20 seconds")),
          20_000,
        );
      }),
    ]);
    observed(result);
    report.progress.push({
      label,
      status: "completed",
      at: new Date().toISOString(),
    });
    await save();
    return result;
  } finally {
    clearTimeout(timer);
  }
}
async function read(context, path, status = 200) {
  const response = await bounded("GET " + path, () =>
    context.request.get(new URL(path, manifest.origin).href, {
      timeout: 20_000,
    }),
  );
  assert.equal(response.status(), status, path);
  return status === 200
    ? bounded("GET JSON " + path, () => response.json())
    : null;
}
function acknowledgeMutation(body, path, actionName, request) {
  assert.ok(
    body && typeof body === "object" && !body.error,
    "Missing mutation acknowledgement.",
  );
  const id = path.split("/").at(-1);
  if (["save", "approve", "deliver"].includes(actionName)) {
    assert.equal(body.draft?.id, id);
    assert.equal(
      body.draft.revision,
      request.expected_revision + (actionName === "deliver" ? 0 : 1),
    );
    if (actionName === "save") {
      assert.equal(body.draft.status, "private_draft");
      assert.equal(body.approval, null);
      assert.deepEqual(body.draft.activity, request.activity);
    } else {
      assert.equal(body.draft.status, "approved");
      assert.equal(body.approval?.draft_id, id);
      assert.ok(body.approval.id);
      if (actionName === "approve") {
        assert.equal(
          body.approval.approved_revision,
          request.expected_revision,
        );
        assert.deepEqual(body.approval.recipient_ids, request.recipient_ids);
        assert.equal(body.delivery, null);
      } else {
        assert.equal(body.approval.id, request.approval_id);
        assert.equal(body.delivery?.approval_id, request.approval_id);
        assert.ok(body.delivery.id);
      }
    }
  } else if (["start", "submit"].includes(actionName)) {
    assert.equal(body.approval_id, path.split("/").at(-2));
    assert.ok(body.started_at && body.attempt_id);
    if (actionName === "submit") {
      assert.ok(body.submitted_at);
      assert.equal(body.response_text, request.response_text);
    }
  } else {
    assert.equal(actionName, "curated-assignment-explicit-activation");
    assert.equal(body.id, path.split("/").at(-2));
    assert.ok(body.teacher_approved_at && body.content_ref);
  }
}
async function action(
  page,
  path,
  expectedAction,
  click,
  matchesRequest = (request) =>
    request.postDataJSON()?.action === expectedAction,
) {
  assert.ok(["start","submit"].includes(expectedAction),"Only new student start/submit permitted in resumed phase");
  assert.equal(path,"/api/student/interventions/"+seam.approval_id+"/followup");
  allowedStudentAction=expectedAction;
  guard(expectedAction);
  const intent = {
    action: expectedAction,
    path,
    status: "intent-recorded",
    at: new Date().toISOString(),
  };
  report.mutations.push(intent);
  await save();
  const promise = page.waitForResponse(
    (response) =>
      new URL(response.url()).pathname === path &&
      response.request().method() === "POST" &&
      matchesRequest(response.request()),
    { timeout: 20_000 },
  );
  // A rejected response wait may settle while click is pending. Its error is
  // still consumed below; suppress only an unhandled-promise notification.
  promise.catch(() => {});
  mutationUncertain = true;
  intent.status = "outcome-unestablished";
  await bounded("click " + expectedAction, click);
  const response = await bounded(
    "response headers " + expectedAction,
    () => promise,
  );
  intent.http_status = response.status();
  intent.request_identity_sha256 = hash(response.request().postData() || "");
  let body;
  await bounded(
    "response body " + expectedAction,
    () => response.text(),
    (text) => {
      intent.response_sha256 = hash(text);
      intent.response_received_at = new Date().toISOString();
      intent.status = "response-requires-reconciliation";
      assert.equal(response.status(), 200, expectedAction + ": " + text);
      body = JSON.parse(text);
      acknowledgeMutation(
        body,
        path,
        expectedAction,
        response.request().postDataJSON(),
      );
      // Only a valid, scoped success acknowledgement establishes the result.
      // Errors and malformed/nonacknowledging 200s retain the uncertainty latch.
      mutationUncertain = false;
      intent.status = "acknowledged";
      intent.completed_at = new Date().toISOString();
    },
  );
  await save();
  report.checks.push({
    action: expectedAction,
    at: new Date().toISOString(),
    http_status: response.status(),
  });
  await save();
  return body;
}
async function selectInterventionPane(page, name) {
  if (page !== teacher || !new URL(page.url()).pathname.startsWith('/teacher/interventions')) return;
  const width = page.viewportSize().width;
  if (width <= 800) {
    const tab = page.getByRole('tab', { name, exact: true });
    await tab.click();
    assert.equal(await tab.getAttribute('aria-selected'), 'true');
  } else if (width <= 1240) {
    const dialog = page.getByRole('dialog', {name:'Evidence', exact:true, includeHidden:true});
    if (name === 'Evidence' && !(await dialog.evaluate(element => element.open)))
      await page.getByRole('button', { name: 'Open Evidence', exact: true }).click();
    if (name !== 'Evidence' && await dialog.evaluate(element => element.open))
      await page.keyboard.press('Escape');
  }
}
async function capture(page, name, allSizes = false, focus = null) {
  const sizes = allSizes
    ? [
        [1440, 1000],
        [1024, 768],
        [390, 844],
        [320, 844],
      ]
    : [[1440, 1000]];
  for (const [width, height] of sizes) {
    await page.setViewportSize({ width, height });
    await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
    await selectInterventionPane(page, focus || /followup|approved|delivered/.test(name) ? "Steps" : "Activity");
    await bounded("fonts for " + name, () =>
      page.evaluate(() => document.fonts.ready),
    );
    let focusedEvidence = null;
    if (focus) {
      const candidates = page.locator(focus.selector);
      const matched = [];
      for (let i = 0; i < await candidates.count(); i++)
        if (await candidates.nth(i).textContent() === focus.expected) matched.push(i);
      assert.equal(matched.length, 1, "Exactly one displayed evidence node must contain the full expected original text");
      const text = candidates.nth(matched[0]);
      assert.equal(await text.textContent(), focus.expected);
      await text.evaluate((element) =>
        element.scrollIntoView({
          block: "center",
          inline: "nearest",
          behavior: "instant",
        }),
      );
      focusedEvidence = await text.evaluate((element) => {
        const rect = element.getBoundingClientRect();
        const hitPoints = [
          rect.top + Math.min(2, rect.height / 4),
          rect.top + rect.height / 2,
          rect.bottom - Math.min(2, rect.height / 4),
        ].map((y) => {
          const hit = document.elementFromPoint(rect.x + rect.width / 2, y);
          return {
            x: rect.x + rect.width / 2,
            y,
            unobscured: hit === element || element.contains(hit),
          };
        });
        return {
          top: rect.top,
          bottom: rect.bottom,
          left: rect.left,
          right: rect.right,
          width: rect.width,
          height: rect.height,
          scroll_y: window.scrollY,
          viewport_height: innerHeight,
          viewport_width: innerWidth,
          hit_points: hitPoints,
          all_sampled_points_unobscured: hitPoints.every(
            (point) => point.unobscured,
          ),
        };
      });
      assert.ok(
        focusedEvidence.top >= 0 &&
          focusedEvidence.bottom <= height &&
          focusedEvidence.left >= 0 &&
          focusedEvidence.right <= width &&
          focusedEvidence.all_sampled_points_unobscured,
        "Exact evidence text must be inside the captured viewport.",
      );
    }
    const file = name + "-" + width + "x" + height + ".png";
    await page.screenshot({ path: resolve(out, file), fullPage: false });
    report.screenshots.push({
      file,
      stage,
      width,
      height,
      url: page.url(),
      ...(focusedEvidence
        ? {
            focused_evidence: {
              ...focusedEvidence,
              selector: focus.selector,
              text_sha256: hash(focus.expected),
            },
          }
        : {}),
      overflow: await page.evaluate(
        () => document.documentElement.scrollWidth > innerWidth + 1,
      ),
    });
  }
  await page.setViewportSize({ width: 1440, height: 1000 });
  await save();
}
async function login(page, role) {
  guard("login-" + role);
  await page.goto(new URL("/login", manifest.origin).href);
  await page
    .getByRole("button", {
      name: role === "teacher" ? "Demo teacher" : "Demo student",
      exact: true,
    })
    .click();
  await page.waitForURL(
    role === "teacher" ? "**/teacher" : "**/study/assignments",
  );
}
function sameOriginal(comparison) {
  assert.equal(comparison.assignment_id, authoring.assignment_id);
  assert.deepEqual(comparison.content_ref, authoring.content_ref);
  const observed = comparison.original_evidence.observations.find(
    (value) => value.attempt.id === authoring.presented_attempt_id,
  );
  assert.ok(observed);
  assert.equal(observed.session_id, authoring.student_session_id);
  assert.equal(observed.student_id, authoring.student_id);
  assert.equal(observed.attempt.response_text, authoring.original_response);
  return comparison.recipients.find(
    (value) => value.student_id === authoring.student_id,
  );
}
async function showTeacherComparison() {
  await bounded("reload teacher comparison", () => teacher.reload());
  await selectInterventionPane(teacher, "Steps");
  const comparisonDisclosure = teacher.getByText("Compare original and follow-up work", {exact:true});
  await comparisonDisclosure.waitFor();
  const comparisonDetails = comparisonDisclosure.locator("..");
  if (!(await comparisonDetails.evaluate(element => element.open))) await comparisonDisclosure.click();
  const recipient = teacher.locator("details.lp-followup-recipient");
  await teacher
    .locator('.lp-intervention-followup[aria-busy="false"]')
    .waitFor();
  await recipient.first().waitFor();
  assert.equal(await recipient.count(), 1);
  await recipient.locator("summary").first().click();
  const originals = recipient.locator("details.lp-followup-original");
  let exactOriginalCount = 0;
  for (let i = 0; i < await originals.count(); i++) {
    const original = originals.nth(i);
    if (await original.locator("blockquote").textContent() === authoring.original_response) {
      exactOriginalCount++;
      if (!(await original.evaluate(element => element.open))) await original.locator(":scope > summary").click();
    }
  }
  assert.equal(exactOriginalCount, 1, "Open only the exact inherited original response, keeping other evidence distinct");
  const visible = await recipient.innerText();
  assert.ok(visible.includes(authoring.original_response.trim()));
  assert.ok(visible.includes(preparation.followup_response));
  return recipient;
}

try {
  release=acquireLock({mode:"browser-intervention-resume-delivered",source:manifest.source,state,project:manifest.project,sourceSha:manifest.sourceSha});
  report.lock_owner=JSON.parse(readFileSync(resolve(LOCK_PATH,"owner.json"),"utf8"));await save();guard("browser-launch");
  browser=await chromium.launch({executablePath:process.env.BROWSER_EXECUTABLE,headless:true});
  const contexts=[await browser.newContext({viewport:{width:1440,height:1000}}),await browser.newContext({viewport:{width:1440,height:1000}})];
  const studentEndpoint="/api/student/interventions/"+seam.approval_id,followupEndpoint=studentEndpoint+"/followup";
  for(const [index,context] of contexts.entries()){
    let loginAllowed=true;
    await context.route("**/*",async route=>{
      const request=route.request(),url=new URL(request.url()),method=request.method();
      if(["data:","blob:"].includes(url.protocol))return route.continue();
      if(url.origin!==manifest.origin){report.blocked_off_origin_requests.push(url.href);return route.abort("blockedbyclient");}
      if(["GET","HEAD","OPTIONS"].includes(method))return route.continue();
      if(loginAllowed&&method==="POST"&&url.pathname==="/api/auth/demo-sign-in"){loginAllowed=false;return route.continue();}
      let body;try{body=request.postDataJSON();}catch{}
      if(index===1&&method==="POST"&&url.pathname===studentEndpoint&&body?.action==="displayed"&&displayAllowed){
        displayAllowed=false;mutationUncertain=true;report.display_acknowledgement={action:"displayed",approval_id:seam.approval_id,status:"outcome-unestablished",at:new Date().toISOString()};await save();return route.continue();
      }
      if(index===1&&method==="POST"&&url.pathname===followupEndpoint&&["start","submit"].includes(body?.action)&&body.action===allowedStudentAction){allowedStudentAction=null;return route.continue();}
      report.blocked_context_writes.push({url:url.href,method,action:body?.action??null});return route.abort("blockedbyclient");
    });
  }
  teacher=await contexts[0].newPage();student=await contexts[1].newPage();for(const p of [teacher,student])p.setDefaultTimeout(20000);
  await login(teacher,"teacher");await login(student,"student");
  stage="reconcile-acknowledged-delivery-and-not-started-followup";
  const endpoint="/api/teacher/interventions/"+preparation.draft_id;
  await teacher.goto(new URL(preparation.teacher_url,manifest.origin).href);
  const review=await read(contexts[0],endpoint);
  assert.equal(review.draft.id,preparation.draft_id);assert.equal(review.approval?.id,seam.approval_id);assert.equal(review.delivery?.id,seam.delivery_id);
  assert.equal(review.approval.draft_id,preparation.draft_id);assert.equal(review.delivery.approval_id,seam.approval_id);
  assert.deepEqual(review.approval.recipient_ids,[authoring.student_id]);assert.deepEqual(review.delivery.recipient_ids,[authoring.student_id]);
  assert.deepEqual(review.approval.content_ref,authoring.content_ref);assert.deepEqual(review.draft.evidence.content_ref,authoring.content_ref);
  assert.equal(review.draft.evidence.observations.find(o=>o.attempt.id===authoring.presented_attempt_id)?.attempt.response_text,authoring.original_response);
  const originalBefore=await read(contexts[0],"/api/teacher/sessions/"+authoring.student_session_id);
  const before=await read(contexts[1],followupEndpoint);assert.equal(before.approval_id,seam.approval_id);
  for(const key of ["started_at","attempt_id","submitted_at","response_text","evaluation_id"])assert.equal(before[key],null,"Already started/submitted: do not replay "+key);
  assert.equal(before.evaluation_status,"not_submitted");
  report.approval_id=seam.approval_id;report.delivery_id=seam.delivery_id;report.reconciled_before_followup=before;
  report.delivery_reconciled={draft_id:review.draft.id,approval_id:review.approval.id,delivery_id:review.delivery.id,recipient_ids:review.approval.recipient_ids,content_ref:review.approval.content_ref};await save();
  stage="same-student-opens-exact-acknowledged-review";
  await student.goto(new URL("/study/assignments",manifest.origin).href);
  const link=student.locator('article.lp-review-card a[href="/study/interventions/'+seam.approval_id+'"]');assert.equal(await link.count(),1);
  await link.click();await student.waitForURL("**/study/interventions/"+seam.approval_id);await student.locator(".lp-review-explanation").scrollIntoViewIfNeeded();
  const delivered=await read(contexts[1],studentEndpoint);assert.equal(delivered.approval_id,seam.approval_id);assert.deepEqual(delivered.content_ref,authoring.content_ref);
  assert.ok(!JSON.stringify(delivered).includes('"rubric"'));assert.ok(!JSON.stringify(delivered).includes('"answer_guidance"'));
  // The existing UI records assistance only when its explanation becomes visible.
  await student.waitForFunction(()=>document.querySelector('.lp-review-explanation')!==null);
  let observed=delivered;
  for(let i=0;i<5&&!observed.displayed_at;i++){await student.waitForTimeout(200);observed=await read(contexts[1],studentEndpoint);}
  assert.ok(observed.displayed_at,"Displayed acknowledgement must be reconciled before a fresh check");
  if(report.display_acknowledgement){report.display_acknowledgement.status="acknowledged-by-authorized-read";report.display_acknowledgement.displayed_at=observed.displayed_at;mutationUncertain=false;}
  await capture(student,"04-student-exact-delivered-review",true);
  const notStarted=await read(contexts[1],followupEndpoint);assert.deepEqual(notStarted,before);
  stage="same-student-starts-new-followup";
  await action(student,followupEndpoint,"start",()=>student.getByRole("button",{name:"Start fresh check",exact:true}).click());
  stage="same-student-submits-followup";await student.locator("#intervention-response").fill(preparation.followup_response);
  report.followup=await action(student,followupEndpoint,"submit",()=>student.getByRole("button",{name:"Submit fresh-check response",exact:true}).click());
  assert.equal(report.followup.response_text,preparation.followup_response);assert.equal(report.followup.evaluation_status,"failed");assert.ok(report.followup.submitted_at);
  await student.getByRole("heading",{name:"Evaluation failed",exact:true}).waitFor();await capture(student,"05-saved-followup-provider-disabled");
  stage="teacher-inspects-linked-provider-disabled-followup";
  report.comparison=await read(contexts[0],endpoint+"/followup");const linked=sameOriginal(report.comparison);
  assert.equal(linked.followup.response_text,preparation.followup_response);assert.equal(linked.followup.evaluation_status,"failed");
  await showTeacherComparison();await capture(teacher,"06-teacher-linked-provider-disabled-followup");
  const after=await read(contexts[0],endpoint);assert.deepEqual(after.approval,review.approval);assert.deepEqual(after.delivery,review.delivery);assert.deepEqual(after.draft,review.draft);
  assert.deepEqual(await read(contexts[0],"/api/teacher/sessions/"+authoring.student_session_id),originalBefore);
  assert.deepEqual(report.blocked_context_writes,[]);assert.deepEqual(report.mutations.map(m=>[m.action,m.http_status,m.status]),["start","submit"].map(a=>[a,200,"acknowledged"]));
  report.functional_completed_through="teacher-inspected-provider-disabled-followup";report.next_step="After normal retry_after, use explicit synthetic evaluation seam with this resumed receipt; never replay prior save/approve/deliver or new start/submit.";
  report.prior_approval_delivery_and_original_unchanged=true;report.status=report.screenshots.some(s=>s.overflow)?"failed-responsive":"passed";
} catch (error) {
  report.status = mutationUncertain ? "uncertain" : "failed";
  report.failure_stage = stage;
  report.error = error.message;
  for (const [name, page] of [
    ["teacher", teacher],
    ["student", student],
  ])
    if (page && !mutationUncertain) {
      try {
        await capture(page, "failure-" + name);
      } catch {
        /* Preserve the original error. */
      }
    }
  process.exitCode = 1;
} finally {
  if (browser) {
    let closed = false;
    try {
      await bounded(
        "close owned browser",
        () => browser.close(),
        () => {
          closed = true;
        },
      );
    } catch (error) {
      browserCloseUncertain = !closed;
      report.browser_close_error = error.message;
    }
  }
  try {
    if (release && (mutationUncertain || browserCloseUncertain)) {
      report.status = "uncertain";
      report.lock_retained = true;
      report.reconciliation_required =
        "Reconcile the recorded request and owned browser/process state before retrying or releasing this exact owned lock. No automatic retry, restart or lock removal.";
      process.exitCode = 1;
    } else {
      release?.();
      report.lock_retained = false;
    }
  } catch (error) {
    report.status = "failed";
    report.lock_release_error = error.message;
    process.exitCode = 1;
  }
  report.finished_at = new Date().toISOString();
  await save();
  if (report.status !== "passed") process.exitCode = 1;
  console.log(
    JSON.stringify({
      phase,
      status: report.status,
      stage,
      report: resolve(out, "report.json"),
    }),
  );
}
