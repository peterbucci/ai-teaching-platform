/** Read-only R03 check against exact inherited accepted followup. */
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { hash,openRuntime } from './read-only-runtime.mjs';
const [stateArg,outArg,playwrightArg,safetyArg]=process.argv.slice(2);
const rt=await openRuntime({stateArg,outArg,playwrightArg,safetyArg,helper:'combined-r03-inherited-followup-labels'});
rt.report.harnessSha256=hash(readFileSync(new URL(import.meta.url)));
rt.report.fixtureOrigin='Explicit clone of original07efb7f fictional acceptance database; this run verifies current rendering and read-only identity only.';
const approval='608d1c43-4cdb-407e-b809-bf373f016372';
const concept='d1edb362-fa58-4e34-b8af-08c1f685e583';
try{
 const {context,page}=await rt.launch('student');
 const endpoint='/api/student/interventions/'+approval+'/followup';
 const before=await rt.get(context,endpoint);
 assert.equal(before.attempt_id,'8ad2d8b8-a662-4647-a1be-a90b4fcbca9d');
 assert.equal(before.evaluation_id,'b2e02dda-4b3b-4ddf-a818-ea7906c0e601');
 assert.equal(before.evaluation_status,'accepted');
 assert.ok(before.results.some(r=>r.concept_id===concept&&r.correctness==='correct'));
 rt.report.fixture={approval,attemptId:before.attempt_id,evaluationId:before.evaluation_id,concept,expectedTitle:'Evaporation'};
 for(const [width,height] of [[1440,1000],[1024,768],[390,844],[320,844]]){
  await rt.run('R03-'+width,'Saved student result shows source-authorized concept name at '+width,page,async()=>{
   await page.setViewportSize({width,height});await page.goto(rt.manifest.origin+'/study/interventions/'+approval);
   await page.getByRole('heading',{name:'Evaluation accepted',exact:true}).waitFor();
   const list=page.locator('.lp-followup-saved ul');await list.waitFor();
   const lines=(await list.locator('li').allTextContents()).map(text=>text.replace(/\s+/g,' ').trim());
   const text=await list.innerText();
   rt.check('R03-'+width,'Evaporation: correct replaces raw concept UUID',lines.includes('Evaporation: correct')&&!text.includes(concept),{lines,text});
   await list.scrollIntoViewIfNeeded();await rt.capture(page,'r03-label-'+width);
   assert.deepEqual(await rt.get(context,endpoint),before,'Read-only result inspection leaves accepted original unchanged');
  });
 }
}catch(error){rt.check('R03-SETUP','Exact inherited fixture is available',false,{error:String(error)});}
finally{await rt.finish();}
