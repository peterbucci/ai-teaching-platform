import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
const root=dirname(fileURLToPath(import.meta.url));
const hash=b=>createHash('sha256').update(b).digest('hex');
const inheritedBytes=readFileSync(join(root,'visual-bundle/inherited-scenario.json'));
const inherited=JSON.parse(inheritedBytes);
const captureScope=['overview','assignments','lessons','evidence','original-response','interventions','roster','learning-insights','roster-student'];
const state=name=>structuredClone(inherited.states.find(s=>s.name===name));
const states=captureScope.filter(n=>n!=='roster-student').map(state);
const get=name=>states.find(s=>s.name===name);
Object.assign(get('overview'),{readySelector:'.ov-workspace',expectedText:'Needs a decision',structureProbes:[{label:'all assignments',selector:'#ov-assignments'},{label:'unfinished work',selector:'#ov-resume'},{label:'recent activity',selector:'#ov-activity'}]});
Object.assign(get('lessons'),{readySelector:'.ll-list',expectedText:'Lessons',mobileLessonProbes:true,structureProbes:[{label:'lesson rows',selector:'.ll-row'},{label:'teaching material section',selector:'#material-library-heading'}]});
Object.assign(get('evidence'),{readySelector:'.wb-response-list'});
Object.assign(get('original-response'),{readySelector:'.wb-original-response'});
Object.assign(get('interventions'),{readySelector:'.lp-intervention-steps'});
Object.assign(get('roster'),{readySelector:'.roster-table',structureProbes:[{label:'concept trails grid',selector:'.roster-table'},{label:'bounded grid scroll',selector:'.roster-table-scroll'}]});
Object.assign(get('learning-insights'),{
  path:'/teacher/insights?assignment=30000000-0000-4000-8000-000000000001&origin=synthetic_fixture&concept=transmission_delay&misconception=transmission_depends_on_distance&view=concerns&returnTo=patterns&workspacePane=main#patterns',
  fixtureLabel:'Separate prepared curated class example from the cloned database, not the connected evaporation journey. Explicit transmission-distance supported concern from approved synthetic histories. Populated investigation required; no empty-state substitution. Prototype concern has different students, evidence and counts.',
  readySelector:'.ci-record .ci-counts',expectedText:'distinct linked responses',
  structureProbes:[{label:'populated concern investigation',selector:'.ci-record .ci-counts'},{label:'evidence action group',selector:'.ci-record .ci-actions'}]
});
states.push({name:'roster-student',path:'/teacher/students?assignment=382f0724-3800-4e6c-8a15-40b4813cb4ab&origin=live_demo&student=10000000-0000-4000-8000-000000000002&rosterPane=main&workspacePane=main',fixtureLabel:'Selected Student One (fictional), inherited evaporation assignment, Work log primary state. Prototype Lena Fischer has different concepts and histories. Read-only Ideas, Summary and Work log pane probes occur after the primary image.',readySelector:'.roster-log',expectedText:'Every saved session',paneProbes:[{label:'Ideas',selector:'.roster-ideas'},{label:'Summary',selector:'.roster-summary'},{label:'Work log',selector:'.roster-log'}]});
assert.equal(states.length,9);
const focused={...inherited,captureScope,scopeReason:'Focused integration comparison: five changed page-owner surfaces plus assignments, dedicated Evidence list/original record and selected Roster Work log. Nine states at 1440, 1024, 390, 320 and actual native200. Unchanged objectives/questions/published/class-progress visual repeats excluded; original full scenario and prior acceptance evidence retained.',provenance:{...inherited.provenance,preparedFullScenarioSha256:hash(inheritedBytes),preparedFullScenario:'inherited-scenario.json',sourceAuditSha:inherited.sourceSha},states};
writeFileSync(join(root,'visual-bundle/focused-scenario.json'),JSON.stringify(focused,null,2)+'\n',{flag:'wx'});
const galleryPath=join(root,'visual-bundle/build-gallery-v2.mjs');
let gallery=readFileSync(galleryPath,'utf8');
gallery=gallery.replace('Teaching Workbench v2.2 — independent combined comparison','Teaching Workbench v2.2 — combined integration comparison');
gallery=gallery.replace('“Learning insights” compares the legacy application page with the prototype\'s corresponding concern workspace because the prototype has no exact route of that name.','“Learning insights” compares the current populated concern investigation with the prototype\'s corresponding concern workspace. Route names and prepared fictional evidence differ. This integration comparison awaits independent acceptance.');
gallery=gallery.replace('metrics:result.metrics,path:result.path,finalUrl:result.finalUrl,files,primaryNative200','metrics:result.metrics,path:result.path,finalUrl:result.finalUrl,readiness:result.readiness,structureChecks:result.structureChecks,paneChecks:result.paneChecks,lessonChecks:result.lessonChecks,files,primaryNative200');
writeFileSync(galleryPath,gallery);
const protoPath=join(root,'visual-bundle/capture-prototype.mjs');
let proto=readFileSync(protoPath,'utf8').replace('<original-export-directory> */','<original-export-directory> [focused-scenario.json] */').replace('NO exact Learning insights prototype route. Corresponding concern investigation in Student work; capability comparison only','Prototype populated concern investigation in Student work; same workspace purpose with different records and route names');
writeFileSync(protoPath,proto);
const commandsPath=join(root,'BROWSER_COMMANDS.txt');
let commands=readFileSync(commandsPath,'utf8').replace('$safety $prototype\r\n','$safety $prototype "$v/visual-bundle/focused-scenario.json"\r\n').replace('$safety $prototype\n','$safety $prototype "$v/visual-bundle/focused-scenario.json"\n').replace('"$v/visual-bundle/inherited-scenario.json"','"$v/visual-bundle/focused-scenario.json"');
commands=commands.replace('The inherited scenario deliberately uses the old exact R07 delivered draft, not the new lifecycle draft. It tests all requested pages/widths/native200 with original saved fixture IDs and explicit data/state differences.','The focused scenario contains nine matching application/prototype states, 45 primary images each: Overview, Assignments, Lessons, Evidence, original response, Interventions, Roster, populated Concerns and selected Roster Work log. It uses the old exact R07 delivered draft. The R06 concern uses the cloned prepared curated fixture rather than the evaporation empty-concern scope. Missing populated data fails readiness; it is not silently replaced. R05 Ideas/Summary/Work log interactions follow primary screenshots at all five sizes; R08 keyboard Details/Search/Clear probes follow primary screenshots at390/320/native200. Inspect functionalProbeFailures independently of capture count. The original full inherited scenario and its hash remain preserved.');
writeFileSync(commandsPath,commands);
const provenancePath=join(root,'BROWSER_BUNDLE_PROVENANCE.json'),provenance=JSON.parse(readFileSync(provenancePath,'utf8'));
provenance.selectorAudit={at:new Date().toISOString(),sourceSha:inherited.sourceSha,status:'offline-preparation-only',captureScope,primaryImagesPerTarget:45,notes:['Await actual loaded owner containers to avoid suspense fallback screenshots.','Dedicated Evidence original-record route retained.','R03 whitespace normalized only; exact Evaporation: correct label and raw-UUID absence remain required.','R06 explicit approved curated supported concern requires populated counts; empty/missing fixture is failure.','Read-only R05 pane and R08 keyboard/search probes run after primary screenshots; failures retained separately.','No DOM/screenshot replacement or application-source edits.'],previousPreparedHashes:provenance.files.filter(f=>f.destination.startsWith('visual-bundle/')).map(f=>({path:f.destination,sha256:f.preparedSha256}))};
writeFileSync(provenancePath,JSON.stringify(provenance,null,2)+'\n');
const finalizePath=join(root,'finalize-browser-bundles.mjs');
let finalize=readFileSync(finalizePath,'utf8').replace("'visual-bundle/inherited-scenario.json'","'visual-bundle/inherited-scenario.json','visual-bundle/focused-scenario.json','prepare-focused-visual.mjs'");
writeFileSync(finalizePath,finalize);
console.log(JSON.stringify({status:'prepared-not-executed',states:captureScope,primaryImagesPerTarget:45}));
