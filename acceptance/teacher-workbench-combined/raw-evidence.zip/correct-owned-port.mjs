// One-time verification-runtime file correction. No Docker or database commands.
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, readdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { acquireLock } from "./safety.mjs";

const root = "C:/Users/sb128/.codex/visualizations/2026/10/25/01a174be-f6b2-7012-b723-c460b8858df5";
const state = join(root, "runtime");
const verification = join(root, "verification");
const sha256 = (bytes) => createHash("sha256").update(bytes).digest("hex");
assert.equal(sha256(readFileSync(join(verification,"safety.mjs"))), "af01b05dd317682a47b6ec64acc5083cae1430383d697dcb1ede53687722c485");
const release = acquireLock({task:"owned teacher combined port correction",project:"lp-teacher-combined-01a174be",state,sourceSha:"c26664e49b7cc15fa7c63828f5c582c9b8cac2d8",operation:"file-only 3417 to 3449"});
try {
  assert(!existsSync(join(state,"original-fixture-clone-completed.json")));
  for (const name of readdirSync(join(state,"runs"))) {
    const path = join(state,"runs",name,"results.json");
    if (!existsSync(path)) continue;
    assert(!["integration","approval"].includes(JSON.parse(readFileSync(path,"utf8")).mode), "Refuse correction after service evidence");
  }
  const paths = {
    runner:join(verification,"runner.mjs"),
    clone:join(verification,"clone-original-fixture.mjs"),
    manifest:join(state,"manifest.json"),
    compose:join(state,"compose.json"),
    env:join(state,".env.acceptance"),
    gateway:join(state,"gateway.conf"),
    provenance:join(verification,"COPY_PROVENANCE.json"),
  };
  const previous = Object.fromEntries(Object.entries(paths).map(([name,path])=>[name,readFileSync(path)]));
  const source = Object.fromEntries(Object.entries(previous).map(([name,bytes])=>[name,bytes.toString("utf8")]));
  const manifest = JSON.parse(source.manifest);
  const compose = JSON.parse(source.compose);
  assert.equal(manifest.project,"lp-teacher-combined-01a174be");
  assert.equal(manifest.sourceSha,"c26664e49b7cc15fa7c63828f5c582c9b8cac2d8");
  assert.equal(manifest.sourceTree,"333b73e1cae1daddf6edd61300655d0b4825ed67");
  assert.equal(manifest.origin,"http://localhost:3417");
  assert.equal(compose.services.app.image,`lp-teacher-combined-01a174be:${manifest.sourceSha}`);
  assert.deepEqual(compose.services.gateway.ports,["127.0.0.1:3417:80"]);
  assert.equal(compose.services.app.environment.DIALOGUE_CHECK_URL,"http://localhost:3417");
  assert(source.env.includes("AUTH_URL=http://localhost:3417\n"));
  assert(source.env.includes("OPENAI_API_KEY=\n") && source.env.includes("OPENAI_MODEL=\n"));
  assert.equal((source.runner.match(/shell: 3417/g)??[]).length,1);
  assert.equal((source.clone.match(/3417/g)??[]).length,2);
  assert.equal((source.gateway.match(/http:\/\/app:3417/g)??[]).length,1);
  const correctionPath = join(state,`port-correction-${new Date().toISOString().replace(/[:.]/g,"-")}`);
  mkdirSync(correctionPath);
  for (const [name,bytes] of Object.entries(previous)) writeFileSync(join(correctionPath,`${name}.before.private`),bytes,{flag:"wx",mode:0o600});
  const next = {...source};
  next.runner = source.runner.replace("shell: 3417","shell: 3449");
  next.clone = source.clone.replaceAll("3417","3449");
  next.compose = source.compose.replaceAll("3417","3449");
  next.env = source.env.replace("AUTH_URL=http://localhost:3417\n","AUTH_URL=http://localhost:3449\n");
  next.gateway = source.gateway.replace("http://app:3417","http://app:3449");
  manifest.origin = "http://localhost:3449";
  manifest.harness.sha256 = sha256(next.runner);
  manifest.harness.authoringTestsSha256 = sha256(readFileSync(join(verification,"authoring-tests.mjs")));
  manifest.runtimeCorrection = {
    oldPort:3417,newPort:3449,reason:"Root verified 3417 occupied by unrelated PID101696; 3449 bind probe succeeded",
    previousCopies:correctionPath,correctedAt:new Date().toISOString(),scope:"owned runtime files only; prior run receipts unchanged",
  };
  next.manifest = `${JSON.stringify(manifest,null,2)}\n`;
  const provenance = JSON.parse(source.provenance);
  provenance.port = 3449;
  for (const entry of provenance.files) if (entry.file === "runner.mjs") entry.destinationSha256 = sha256(next.runner);
  provenance.preparedClone.sha256 = sha256(next.clone);
  provenance.runtimeCorrections ??= [];
  provenance.runtimeCorrections.push(manifest.runtimeCorrection);
  next.provenance = `${JSON.stringify(provenance,null,2)}\n`;
  const envLines = (text)=>Object.fromEntries(text.trim().split(/\r?\n/).map((line)=>{const i=line.indexOf("=");return [line.slice(0,i),line.slice(i+1)];}));
  const beforeEnvironment = envLines(source.env), afterEnvironment = envLines(next.env);
  for (const [name,value] of Object.entries(beforeEnvironment)) if (name!=="AUTH_URL") assert.equal(afterEnvironment[name],value);
  assert(!next.runner.includes("shell: 3417"));
  assert(!next.clone.includes("3417"));
  assert(!next.compose.includes("3417"));
  assert(!next.gateway.includes("3417"));
  for (const [name,path] of Object.entries(paths)) writeFileSync(path,next[name]);
  const receipt = {
    status:"pass",operation:"file-only correction",oldPort:3417,newPort:3449,project:manifest.project,
    applicationSha:manifest.sourceSha,applicationTree:manifest.sourceTree,privateBackups:correctionPath,
    files:Object.entries(paths).map(([name,path])=>({name,path,previousSha256:sha256(previous[name]),currentSha256:sha256(readFileSync(path))})),
    envChangedKeys:["AUTH_URL"],secretsPreserved:true,providersDisabled:true,previousRunReceiptsUnchanged:true,
    runtimeExecution:"none; root must rerun cached build to apply container configuration",finishedAt:new Date().toISOString(),
  };
  writeFileSync(join(correctionPath,"receipt.json"),`${JSON.stringify(receipt,null,2)}\n`,{flag:"wx"});
  console.log(JSON.stringify({status:receipt.status,port:3449,receipt:join(correctionPath,"receipt.json")}));
} finally { release(); }
