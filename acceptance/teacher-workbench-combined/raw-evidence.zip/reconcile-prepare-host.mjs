import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,unlinkSync,rmdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
const root=dirname(fileURLToPath(import.meta.url)),out=join(root,'new-intervention-prepare-01');
const lock='C:/Users/sb128/AppData/Local/learning-pulse-acceptance.lock',ownerPath=join(lock,'owner.json');
const owner=JSON.parse(readFileSync(ownerPath,'utf8'));
assert.equal(owner.token,'7106e4e3-12e4-488c-8067-cf0c8cdecf00');assert.equal(owner.pid,144392);assert.equal(owner.mode,'guarded-fixture-prepare');
const old=JSON.parse(readFileSync(join(out,'host-receipt.json'),'utf8')),m=JSON.parse(readFileSync(join(owner.state,'manifest.json'),'utf8'));
assert.equal(owner.project,old.project);assert.equal(owner.sourceSha,old.source_sha);assert.equal(m.sourceSha,old.source_sha);assert.equal(m.sourceTree,old.source_tree);assert.equal(m.origin,'http://localhost:3449');
let alive=false;try{process.kill(owner.pid,0);alive=true;}catch(error){assert.equal(error.code,'ESRCH');}assert.equal(alive,false,'Original lock owner still alive');
const {preflight,MIN_RUNTIME_GIB}=await import('./journey-bundle/safety.mjs');
const receipt={category:'Authorized stopped-owner reconciliation',startedAt:new Date().toISOString(),owner,originalWrapperSha256:createHash('sha256').update(readFileSync(join(out,'host-receipt.json'))).digest('hex'),checks:[],lockReleased:false};
const save=()=>writeFileSync(join(out,'reconciliation-host.json'),JSON.stringify(receipt,null,2)+'\n');
function docker(label,args){const gate=preflight({source:m.source,state:owner.state,minimumGiB:MIN_RUNTIME_GIB,explicitPath:m.dockerDataPath||undefined,probeContainer:m.storageProbeContainer||undefined});assert.equal(gate.pass,true);receipt.checks.push({label,gate});save();const r=spawnSync('docker',args,{encoding:'utf8',timeout:60000,windowsHide:true});writeFileSync(join(out,label+'.log'),(r.stdout??'')+(r.stderr??''),{flag:'wx'});assert.equal(r.status,0,r.stderr);return r.stdout;}
const container=old.container;
try{
 const identity=docker('reconciliation-identity',['inspect',container,'--format','{{.Name}}|{{.Image}}|{{index .Config.Labels "com.docker.compose.project"}}|{{.State.Running}}']).trim().split('|');assert.deepEqual(identity,['/'+container,old.image_id,old.project,'true']);
 const processes=docker('reconciliation-processes-before',['top',container,'-eo','pid,args']);assert.equal(processes.includes(old.container_paths.script),false,'Fixture process remains alive');
 const script='/tmp/acceptance-reconciliation-10781145.mjs',result='/tmp/acceptance-reconciliation-10781145.json';
 docker('reconciliation-copy-helper',['cp',join(root,'journey-bundle/reconcile-rejected-prepare.mjs'),container+':'+script]);
 docker('reconciliation-read-only',['exec','-e','OPENAI_API_KEY=','-e','OPENAI_MODEL=','-e','ACCEPTANCE_PROJECT='+m.project,'-e','ACCEPTANCE_SOURCE_SHA='+m.sourceSha,'-e','ACCEPTANCE_SOURCE_TREE='+m.sourceTree,container,'node','--experimental-strip-types','--conditions=react-server',script,old.container_paths.output,result]);
 docker('reconciliation-copy-receipt',['cp',container+':'+result,join(out,'reconciliation.json')]);
 const report=JSON.parse(readFileSync(join(out,'reconciliation.json'),'utf8'));assert.equal(report.status,'reconciled-terminal-failure');
 const after=docker('reconciliation-processes-after',['top',container,'-eo','pid,args']);assert.equal(after.includes(old.container_paths.script),false);assert.equal(after.includes(script),false);
 assert.deepEqual(JSON.parse(readFileSync(ownerPath,'utf8')),owner);try{process.kill(owner.pid,0);throw Error('Original owner is alive');}catch(error){assert.equal(error.code,'ESRCH');}
 receipt.status='terminal-failure-reconciled';receipt.dataReceiptSha256=createHash('sha256').update(readFileSync(join(out,'reconciliation.json'))).digest('hex');receipt.finishedAt=new Date().toISOString();save();
 unlinkSync(ownerPath);rmdirSync(lock);receipt.lockReleased=true;save();
 console.log(JSON.stringify({status:receipt.status,lockReleased:true,report:join(out,'reconciliation.json')}));
}catch(error){receipt.status='reconciliation-failed';receipt.error=error.message;save();throw error;}
