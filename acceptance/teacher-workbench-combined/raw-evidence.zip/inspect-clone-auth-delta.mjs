// Read-only diagnosis of the preserved clone failure; deliberately cannot release its lock.
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { LOCK_PATH, preflight, MIN_RUNTIME_GIB } from "./safety.mjs";
const root="C:/Users/sb128/.codex/visualizations/2026/10/25/01a174be-f6b2-7012-b723-c460b8858df5";
const state=join(root,"runtime");
const failedDirectory=join(state,"clone-original-2026-10-25T20-41-48-928Z");
const readJson=(path)=>JSON.parse(readFileSync(path,"utf8"));
const failed=readJson(join(failedDirectory,"receipt.json"));
const manifest=readJson(join(state,"manifest.json"));
const owner=readJson(join(LOCK_PATH,"owner.json"));
assert.equal(owner.task,"final teacher combined original fixture clone");
assert.equal(owner.project,"lp-teacher-combined-01a174be");
assert.equal(owner.sourceSha,"c26664e49b7cc15fa7c63828f5c582c9b8cac2d8");
assert(failed.targetMutationStarted&&failed.lockRetainedForReconciliation);
let priorAlive=true;try{process.kill(owner.pid,0);}catch(error){if(error.code==="ESRCH")priorAlive=false;else throw error;}
assert(!priorAlive,"Clone worker still alive");
const report={status:"inspecting",failedReceipt:join(failedDirectory,"receipt.json"),checks:[],originalSourceUnchanged:false,targetDomainRowsUnchanged:false,lockReleased:false,writes:0};
const hash=(value)=>createHash("sha256").update(value).digest("hex");
function run(name,args,{allowStderr=false}={}) {
  const safety=preflight({source:manifest.source,state,minimumGiB:MIN_RUNTIME_GIB,explicitPath:manifest.dockerDataPath,probeContainer:failed.source.container});
  report.checks.push({name:`preflight:${name}`,...safety});assert(safety.pass);
  const result=spawnSync("docker",args,{encoding:"utf8",windowsHide:true,maxBuffer:32*1024*1024,timeout:60_000});
  assert.equal(result.status,0,`${name} failed`);report.checks.push({name,pass:true});
  return allowStderr?`${result.stdout}\n${result.stderr}`:result.stdout.trim();
}
const query=(container,name,sql)=>run(name,["exec","-e","PGOPTIONS=-c default_transaction_read_only=on",container,"psql","-X","-U","postgres","-d","learning_platform","-At","-v","ON_ERROR_STOP=1","-c",sql]);
const snapshot=(container,label)=>{
  const names=query(container,`${label}-tables`,"SELECT tablename FROM pg_tables WHERE schemaname='public' ORDER BY tablename").split(/\r?\n/).filter(Boolean);
  const statements=names.map((name)=>{assert(/^[a-z_][a-z0-9_]*$/.test(name));return `SELECT '${name}' AS name,count(*)::text AS count,md5(coalesce(string_agg(row_to_json(t)::text,E'\\n' ORDER BY row_to_json(t)::text),'')) AS fingerprint FROM "${name}" t`;});
  return JSON.parse(query(container,`${label}-fingerprints`,`SELECT jsonb_agg(f ORDER BY name) FROM (${statements.join(" UNION ALL ")}) f`)).map((entry)=>({...entry,count:Number(entry.count)}));
};
for(const [side,project] of [["source","lp-v22-final-01a173d6"],["target","lp-teacher-combined-01a174be"]]) {
  const info=JSON.parse(run(`${side}-identity`,["inspect",failed[side].container]))[0];
  assert.equal(info.Id,failed[side].containerId);assert.equal(info.Config.Labels["com.docker.compose.project"],project);
}
report.sourceNow=snapshot(failed.source.container,"source-now");
assert.deepEqual(report.sourceNow,failed.source.before,"Original source rows changed");report.originalSourceUnchanged=true;
report.targetNow=snapshot(failed.target.container,"target-now");
const domain=(rows)=>rows.filter((entry)=>entry.name!=="auth_session");
assert.deepEqual(domain(report.targetNow),domain(failed.source.before),"Delta extends beyond auth_session");report.targetDomainRowsUnchanged=true;
const idQuery='SELECT coalesce(jsonb_agg(id ORDER BY id),\'[]\'::jsonb) FROM public.auth_session';
const sourceIds=new Set(JSON.parse(query(failed.source.container,"source-session-ids",idQuery)));
const targetIds=JSON.parse(query(failed.target.container,"target-session-ids",idQuery));
const newIds=targetIds.filter((id)=>!sourceIds.has(id));
assert.equal(newIds.length,1,"Expected exactly one new auth session");
assert.equal(targetIds.length,sourceIds.size+1);
const literal=(text)=>`'${text.replaceAll("'","''")}'`;
report.addedAuthSessions=JSON.parse(query(failed.target.container,"new-session-public-metadata",`SELECT jsonb_agg(jsonb_build_object('sessionId',s.id,'actorId',s."userId",'email',u.email,'createdAt',s."createdAt",'updatedAt',s."updatedAt",'expiresAt',s."expiresAt")) FROM auth_session s JOIN auth_user u ON u.id=s."userId" WHERE s.id=${literal(newIds[0])}`));
assert(report.addedAuthSessions.every((entry)=>entry.email.endsWith("@example.invalid")));
report.targetOriginalAuthRowsFingerprint=query(failed.target.container,"original-auth-rows-preserved",`SELECT md5(coalesce(string_agg(row_to_json(t)::text,E'\\n' ORDER BY row_to_json(t)::text),'')) FROM (SELECT * FROM auth_session WHERE id<>${literal(newIds[0])}) t`);
assert.equal(report.targetOriginalAuthRowsFingerprint,failed.source.before.find((entry)=>entry.name==="auth_session").fingerprint,"An original auth session row changed");
const logs=run("owned-app-startup-log",["logs","--since",failed.startedAt,"lp-teacher-combined-01a174be-app-1"],{allowStderr:true});
report.appLogs={sha256:hash(logs),zeroMigrationsApplied:/Database migrations ready: 0 applied/.test(logs),ready:/Ready in/.test(logs),explicitAuthRouteLog:/\/api\/auth\//.test(logs),rawLogsPublished:false};
report.status="read-only diagnosis passed";report.finishedAt=new Date().toISOString();
writeFileSync(join(failedDirectory,"auth-delta-inspection.json"),`${JSON.stringify(report,null,2)}\n`,{flag:"wx"});
console.log(JSON.stringify({status:report.status,originalSourceUnchanged:report.originalSourceUnchanged,targetDomainRowsUnchanged:report.targetDomainRowsUnchanged,addedAuthSessions:report.addedAuthSessions,appLogs:report.appLogs,lockReleased:false}));
