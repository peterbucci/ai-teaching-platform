import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const original=readFileSync('verification/visual-bundle/build-gallery-v2.mjs','utf8');
const revised=original.replace('"Changes required","Not verified"','"Changes required","Not verified", "Compared; independent acceptance pending"');
if(original===revised)throw new Error('No gallery change');
writeFileSync('verification/visual-bundle/build-gallery-v3.mjs',revised);
const review={
 overview:{classification:'Changes required',reason:'R04 whole-course decision list, assignment rail and resume work are present and functional. Section filters and named/repeated-versus-contrary prioritization remain incomplete (P2).'},
 assignments:{classification:'Changes required',reason:'Existing grouped discovery and navigation pass. Prototype answered/enrolled and answer-count row summaries remain absent (P2; inherited, not an established merge regression).'},
 lessons:{classification:'Compared; independent acceptance pending',reason:'R08 mobile spacing and native200 first-row visibility corrected. Six long synthetic titles differ from three prototype lessons. Residual row density/column-heading styling is P3.'},
 evidence:{classification:'Compared; independent acceptance pending',reason:'Responsive list/record/context and functional history/focus navigation preserved. Prototype capture is unselected; application selects latest. Excerpt density and pane vocabulary differ (P3).'},
 'original-response':{classification:'Changes required',reason:'Original text, accepted evaluation and source remain exact. Prototype compact chronological Context chain differs from source-first sections/links (P2 inherited). Entry contexts differ; no broken Concern return inferred.'},
 interventions:{classification:'Compared; independent acceptance pending',reason:'R07 hydration and R09 tablet/Steps corrections verified. Delivered application preview and approved-undelivered prototype editor are explicitly different states; functional lifecycle reported separately.'},
 roster:{classification:'Changes required',reason:'R05 student/concept grid and intervention summaries restored. Framing pushes grid below native200 first viewport; only part of first row at320 (P2). Actual27enrolled/1concept differs from prototype18/5.'},
 'learning-insights':{classification:'Changes required',reason:'R06 populated concern workspace restored with exact evidence and preparation handoff. Native200 density hides initial caution/action; class-grid and side-by-side comparison remain omitted (P2).'},
 'roster-student':{classification:'Changes required',reason:'R05 Ideas/Work log/Summary restored; pane probes pass. Original work below first viewport at1024/native200 and Summary activity counts differ from prototype correctness-by-situation denominators (P2). Log is assessed responses/assistance, not all dialogue.'}
};
writeFileSync('verification/final-visual-review.json',JSON.stringify(review,null,2));
const hash=t=>createHash('sha256').update(t).digest('hex');
writeFileSync('verification/GALLERY_REVISION_03.json',JSON.stringify({original:'visual-bundle/build-gallery-v2.mjs',originalSha256:hash(original),updated:'visual-bundle/build-gallery-v3.mjs',updatedSha256:hash(revised),change:'Add honest compared-but-independent-acceptance-pending classification; no acceptance inferred by generator. No screenshots or raw capture receipts changed.'},null,2));

