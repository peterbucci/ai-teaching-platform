import assert from 'node:assert/strict';
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { createHash, randomUUID } from 'node:crypto';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = dirname(fileURLToPath(import.meta.url));
const old = 'C:/Users/sb128/.codex/worktrees/workbench-v22-final-acceptance-report/LearningPlatform/acceptance/v22/snapshots/2026-10-25-final-07efb7f8';
const sha = 'c26664e49b7cc15fa7c63828f5c582c9b8cac2d8', tree = '333b73e1cae1daddf6edd61300655d0b4825ed67';
const project = 'lp-teacher-combined-01a174be', origin = 'http://localhost:3449';
const hash = b => createHash('sha256').update(b).digest('hex');
const records = [];
function adapt(text) { return text.replaceAll('07efb7f821339538800f150f57b298eb2e606be3',sha).replaceAll('948b9a6005a056c97f10d181c589b5352d6221f3',tree).replaceAll('lp-v22-final-01a173d6',project).replaceAll('http://localhost:3396',origin).replaceAll('Number(origin.port), 3396','Number(origin.port), 3449'); }
function copy(src,dest,edit=x=>x,unchanged=false) {
  const before=readFileSync(join(old,src)); const after=unchanged?before:Buffer.from(edit(adapt(before.toString('utf8'))));
  const output=join(root,dest); assert.equal(existsSync(output),false,output+' already exists'); mkdirSync(dirname(output),{recursive:true});writeFileSync(output,after);
  records.push({source:join(old,src),destination:dest,originalSha256:hash(before),preparedSha256:hash(after),adaptation:unchanged?'Byte-identical reviewed safety module':'Exact candidate/runtime pin adaptation plus documented bounded changes'});
}
for(const name of ['capture-common.mjs','capture-application-v3.mjs','capture-prototype.mjs','capture-prototype-objectives.mjs','build-gallery-v2.mjs']) copy('visual-bundle/'+name,'visual-bundle/'+name);
copy('journey-bundle/read-only-runtime.mjs','journey-bundle/read-only-runtime.mjs');
copy('journey-bundle/safety.mjs','journey-bundle/safety.mjs',x=>x,true);
copy('journey-bundle/guarded-container-fixture.mjs','journey-bundle/guarded-container-fixture.mjs',text=>text.replace(/"prepare-draft",\s*"evaluate-followup",\s*"evaluate-study",/,'"evaluate-followup",'));
copy('journey-bundle/intervention-continuation-fixture.mjs','journey-bundle/intervention-continuation-fixture.mjs',text=>{
  text=text.replace('assert.ok(["prepare", "prepare-draft", "evaluate-followup"].includes(mode));','assert.ok(["prepare", "evaluate-followup"].includes(mode));');
  text=text.replace('const authoring = mode === "prepare" ? input : mode === "prepare-draft" ? input.authoring : input.preparation.authoring;','const authoring = mode === "prepare" ? input.authoring : input.preparation.authoring;\nconst requestNamespace = mode === "prepare" ? input.request_nonce : input.preparation.request_namespace;\nassert.match(requestNamespace, /^[a-f0-9-]{36}$/);\nif (mode === "prepare") assert.equal(input.category, "inherited-fictional-evidence-new-private-draft");');
  let from=text.indexOf('if (mode === "prepare-draft") {'),to=text.indexOf('assert.equal(authoring.sha ??',from);assert(from>0&&to>from);text=text.slice(0,from)+text.slice(to);
  text=text.replace('assert.equal(authoring.sha ?? authoring.sourceSha, pinnedSha);','assert.equal(authoring.sha ?? authoring.sourceSha, "07efb7f821339538800f150f57b298eb2e606be3");');
  text=text.replace('assert.equal(authoring.tree ?? authoring.sourceTree, pinnedTree);','assert.equal(authoring.tree ?? authoring.sourceTree, "948b9a6005a056c97f10d181c589b5352d6221f3");');
  text=text.replace('assert.equal(authoring.origin, process.env.AUTH_URL);','assert.equal(authoring.origin, "http://localhost:3396"); // Historical fixture provenance; current runtime is checked separately.');
  text=text.replace('  authoring,\n};','  authoring,\n  request_namespace: requestNamespace,\n  fixture_scope: "Original lesson/answer/accepted evaluation inherited from the explicitly cloned fictional baseline; no new authoring or original evaluation/controller execution is claimed. New private draft and subsequent browser lifecycle run on the current candidate.",\n};');
  text=text.replace('hash(authoring.student_session_id + ":" + label)','hash(requestNamespace + ":" + authoring.student_session_id + ":" + label)');
  from=text.indexOf('    if (!accepted) {');to=text.indexOf('    report.original_evaluation_id = accepted.id;',from);assert(from>0&&to>from);
  text=text.slice(0,from)+'    assert.ok(accepted, "Require the inherited accepted original; never reevaluate it");\n    assert.equal(accepted.id, input.existing_evaluation_id);\n    draftOnlyOriginalEvaluationSnapshot = accepted;\n    report.seams.push({kind:"inherited-original-answer", read_only:true, evaluation_id:accepted.id, model:accepted.evaluator.model, reevaluated:false});\n'+text.slice(to);
  from=text.indexOf('    // Use the existing reviewed controller');to=text.indexOf('    save();\n    const selection =',from);assert(from>0&&to>from);
  text=text.slice(0,from)+'    report.original_evaluation_and_controller_read_only = true;\n    report.controller = {evaluation_id:accepted.id, applied_result:accepted.applied_result, reapplied:false};\n'+text.slice(to);
  from=text.indexOf('    if (input.phase === "inspect-submitted") {');to=text.indexOf('    assert.ok(\n      ["passed", "failed-responsive"]',from);assert(from>0&&to>from);
  text=text.slice(0,from)+'    assert.equal(input.phase, "review-and-submit", "A new ordinary completed browser receipt is required; historical resumes are unsupported");\n'+text.slice(to);
  from=text.indexOf('  if(draftOnlyOriginalEvaluationSnapshot)');to=text.indexOf('  report.status = "completed";',from);assert(from>0&&to>from);
  text=text.slice(0,from)+'  assert.deepEqual(afterOriginal, original, "Every inherited original session/evidence field remains unchanged");\n  report.inherited_original_unchanged = true;\n'+text.slice(to);
  text=text.replace('const { evaluateSubmittedAttempt } =\n  await import("/app/lib/evaluation/evaluate.ts");\n','').replace('const { applyTutoring } = await import("/app/lib/tutoring/store.ts");\n','');
  return text;
});
copy('journey-bundle/intervention-continuation-browser.mjs','journey-bundle/intervention-continuation-browser.mjs',text=>{
  text=text.replace('    "curated-activation",\n','');
  text=text.replace('  await selectInterventionPane(teacher, "Steps");\n  await teacher\n    .getByRole("heading", {\n      name: "Before and after the activity",\n      exact: true,\n    })\n    .waitFor();','  await selectInterventionPane(teacher, "Steps");\n  const comparisonDisclosure = teacher.getByText("Compare original and follow-up work", {exact:true});\n  await comparisonDisclosure.waitFor();\n  const comparisonDetails = comparisonDisclosure.locator("..");\n  if (!(await comparisonDetails.evaluate(element => element.open))) await comparisonDisclosure.click();');
  return text;
});
// These helpers exercise only existing saved data or current navigation contracts.
for(const name of ['six-blocker-browser.mjs','navigation-supplement-browser.mjs']) copy('journey-bundle/'+name,'journey-bundle/'+name);
const oldReportPath=join(old,'authoring-continuation-02/report.json'), oldReport=JSON.parse(readFileSync(oldReportPath,'utf8'));
const keys=['status','sourceSha','sourceTree','sha','tree','origin','student_id','lesson_id','assignment_id','student_session_id','presented_attempt_id','content_ref','source_id','source_version','published_version','original_response','class_id','run_id','functional_completed_through','target','paid_calls'];
const authoring=Object.fromEntries(keys.map(k=>[k,oldReport[k]]));
const descriptor={category:'inherited-fictional-evidence-new-private-draft',sourceSha:sha,sourceTree:tree,project,origin,request_nonce:randomUUID(),existing_evaluation_id:'2531aac6-c71d-400a-948d-4bb29ac79535',historicalReceipt:{file:oldReportPath,sha256:hash(readFileSync(oldReportPath)),interpretation:'Historical fictional fixture provenance only. It is not a new-candidate authoring result.'},authoring};
mkdirSync(join(root,'journey-bundle'),{recursive:true});writeFileSync(join(root,'journey-bundle/inherited-fixture.json'),JSON.stringify(descriptor,null,2)+'\n',{flag:'wx'});
const oldScenario=JSON.parse(readFileSync(join(old,'visual-bundle/application-scenario-final-01.json'),'utf8'));
const scenario={...oldScenario,sourceSha:sha,sourceTree:tree,fixtureLabel:'New combined candidate on an explicit clone of the prior fictional acceptance database. Original fixture identities preserved; no new authoring claimed. Source/head and saved records are checked independently.',provenance:{historicalScenarioSha256:hash(readFileSync(join(old,'visual-bundle/application-scenario-final-01.json'))),historicalSnapshot:'07efb7f821339538800f150f57b298eb2e606be3',historicalFixtureClone:true},states:oldScenario.states.map(s=>({...s,fixtureLabel:'Inherited fictional acceptance fixture; counts/lifecycle differ from prototype. '+s.fixtureLabel}))};
scenario.states.find(s=>s.name==='overview').path='/teacher';
scenario.states.find(s=>s.name==='overview').fixtureLabel='Whole-course Overview on cloned fictional database, including multiple assignments and private lesson work. Counts differ from prototype.';
scenario.states.find(s=>s.name==='roster').fixtureLabel='Combined Roster workspace using inherited evaporation assignment; verify visible concept trails, intervention summaries, and new focused student workspaces.';
writeFileSync(join(root,'visual-bundle/inherited-scenario.json'),JSON.stringify(scenario,null,2)+'\n',{flag:'wx'});
writeFileSync(join(root,'BROWSER_BUNDLE_PROVENANCE.json'),JSON.stringify({preparedAt:new Date().toISOString(),status:'prepared-not-executed',sourceSha:sha,sourceTree:tree,project,origin,sourceSnapshot:old,files:records,adaptations:['Exact application SHA/tree/project/origin pins','New private-draft mode requires inherited accepted evaluation and verifies full original session equality; skips original evaluation and tutoring controller entirely','New nonce derives idempotent draft/request IDs distinct from prior run; no existing private draft is approved or delivered again','Current completed-stage comparison disclosure is opened through its real control','Visual inherited fixture scenario labels provenance; no historical report promoted to new-candidate pass'],limitations:['No runtime/browser/database command executed by preparer','Current data must actually be restored and independently verified before these helpers run','Only normal completed review-and-submit receipts may drive evaluation; unknown/failed mutations require a fresh scoped read-only reconciliation','Six-blocker helper retains historical readiness assumptions; navigation supplement is the bounded replacement for old S1/C2 waits']},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({prepared:records.length,root,sourceSha:sha,sourceTree:tree}));
