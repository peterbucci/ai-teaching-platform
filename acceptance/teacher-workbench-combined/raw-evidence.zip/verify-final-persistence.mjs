// Verification only: one owned database restart, or a separate read-only reconciliation.
// No original acceptance database is accessed. No model or login requests are made.
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, readdirSync, rmdirSync, unlinkSync, writeFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { acquireLock, LOCK_PATH, preflight, MIN_RUNTIME_GIB } from "./safety.mjs";

const root = "C:/Users/sb128/.codex/visualizations/2026/10/25/01a174be-f6b2-7012-b723-c460b8858df5";
const state = join(root, "runtime");
const project = "lp-teacher-combined-01a174be";
const databaseContainer = `${project}-db-1`;
const appContainer = `${project}-app-1`;
const applicationSha = "c26664e49b7cc15fa7c63828f5c582c9b8cac2d8";
const applicationTree = "333b73e1cae1daddf6edd61300655d0b4825ed67";
const origin = "http://localhost:3449";
const database = "learning_platform";
const task = "final teacher combined persistence";
const markerPath = join(state, "persistence-restart-requested.json");
const hash = (bytes) => createHash("sha256").update(bytes).digest("hex");
const readJson = (path) => JSON.parse(readFileSync(path,"utf8"));
const writeJson = (path,value,exclusive=false) => writeFileSync(path,`${JSON.stringify(value,null,2)}\n`,exclusive?{flag:"wx"}:{});
const [mode, ...args] = process.argv.slice(2);
if (!["restart","reconcile"].includes(mode)) {
  console.log("Prepared only. Usage: verify-final-persistence.mjs restart --browsers-closed OR reconcile <prior-receipt.json> --browsers-closed. Reconcile never restarts anything.");
  process.exit(0);
}
assert.equal(args.at(-1),"--browsers-closed","Caller must finish browser jobs and close their profiles first");
assert.equal(args.length,mode==="restart"?1:2);
const manifest=readJson(join(state,"manifest.json"));
assert.equal(manifest.project,project);
assert.equal(manifest.sourceSha,applicationSha);
assert.equal(manifest.sourceTree,applicationTree);
assert.equal(manifest.origin,origin);
assert.equal(hash(readFileSync(new URL("./safety.mjs",import.meta.url))),"af01b05dd317682a47b6ec64acc5083cae1430383d697dcb1ede53687722c485");
const environment={...process.env,OPENAI_API_KEY:"",OPENAI_MODEL:""};
delete environment.DATABASE_URL;
delete environment.COMPOSE_FILE;
delete environment.COMPOSE_PROJECT_NAME;
let release;
let restartRequested=false;
let original;
let receipt;
let output;
let receiptPath;
let usingRetainedLock=false;
let completed=false;
const save=()=>writeJson(receiptPath,receipt);
function safe(name) {
  const observation=preflight({source:manifest.source,state,minimumGiB:MIN_RUNTIME_GIB,explicitPath:manifest.dockerDataPath,probeContainer:databaseContainer});
  receipt.checks.push({name:`preflight:${name}`,...observation}); save();
  assert(observation.pass,`Storage preflight failed before ${name}`);
}
function run(name,command,argv,{allowNotReady=false,...options}={}) {
  safe(name);
  const result=spawnSync(command,argv,{encoding:"utf8",windowsHide:true,env:environment,maxBuffer:128*1024*1024,timeout:90_000,...options});
  receipt.checks.push({name,exitCode:result.status,pass:result.status===0&&!result.error,expectedReadinessPoll:allowNotReady,finishedAt:new Date().toISOString()}); save();
  if (allowNotReady && result.status!==0 && !result.error) return null;
  if (result.status!==0 || result.error) throw Error(`${name} failed (exit ${result.status}); retain the receipt and inspect state before continuing`);
  return result.stdout.trim();
}
const inspect=(name)=>JSON.parse(run(`inspect-${name}`,"docker",["container","inspect",name]))[0];
const query=(name,sql)=>run(name,"docker",["exec","-e","PGOPTIONS=-c default_transaction_read_only=on",databaseContainer,"psql","-X","-U","postgres","-d",database,"-At","-v","ON_ERROR_STOP=1","-c",sql]);
function fingerprint(label) {
  const names=query(`${label}-table-list`,"SELECT tablename FROM pg_tables WHERE schemaname='public' ORDER BY tablename").split(/\r?\n/).filter(Boolean);
  assert(names.length>20,"Expected populated application schema");
  const selects=names.map((name)=>{
    assert(/^[a-z_][a-z0-9_]*$/.test(name),"Unexpected public table identifier");
    return `SELECT '${name}' AS name,count(*)::text AS count,md5(coalesce(string_agg(row_to_json(t)::text,E'\\n' ORDER BY row_to_json(t)::text),'')) AS fingerprint FROM "${name}" t`;
  });
  // Complete JSON is parsed; no assumption that PostgreSQL emits one line.
  const tables=JSON.parse(query(`${label}-table-fingerprints`,`SELECT jsonb_agg(f ORDER BY name) FROM (${selects.join(" UNION ALL ")}) f`));
  assert(Array.isArray(tables)&&tables.length===names.length,"Incomplete table fingerprints");
  const canonical=tables.map((entry)=>({...entry,count:Number(entry.count)}));
  return {tables:canonical,sha256:hash(JSON.stringify(canonical)),scope:"Every public table, including original evidence, source/version records, migrations, auth and rate-limit rows"};
}
function identity(label) {
  const info=inspect(databaseContainer);
  assert.equal(info.Name,`/${databaseContainer}`);
  assert.equal(info.Config.Labels["com.docker.compose.project"],project);
  assert.equal(info.Config.Labels["com.docker.compose.service"],"db");
  assert(info.State.Running);
  const volume=info.Mounts.find((mount)=>mount.Type==="volume"&&mount.Name===`${project}_postgres_data`&&mount.Destination==="/var/lib/postgresql/data");
  assert(volume,"Wrong project-owned PostgreSQL volume");
  const app=inspect(appContainer);
  assert.equal(app.Config.Labels["com.docker.compose.project"],project);
  assert.equal(app.Config.Image,`${project}:${applicationSha}`);
  const expectedImage=run(`${label}-pinned-image`,"docker",["image","inspect",`${project}:${applicationSha}`,"--format","{{.Id}}"]);
  assert.equal(app.Image,expectedImage);
  const appEnvironment=Object.fromEntries(app.Config.Env.map((line)=>{const i=line.indexOf("=");return [line.slice(0,i),line.slice(i+1)];}));
  assert.equal(appEnvironment.OPENAI_API_KEY,"");
  assert.equal(appEnvironment.OPENAI_MODEL,"");
  assert.equal(appEnvironment.AUTH_URL,origin);
  const systemIdentifier=query(`${label}-postgres-system-identifier`,"SELECT system_identifier FROM pg_control_system()");
  return {
    dbContainerId:info.Id,dbContainerName:databaseContainer,dbStartedAt:info.State.StartedAt,dbRestartCount:info.RestartCount,
    volume:{name:volume.Name,source:volume.Source,destination:volume.Destination,readWrite:volume.RW},systemIdentifier,
    appContainerId:app.Id,appImageId:app.Image,appImageReference:app.Config.Image,origin,providersDisabled:true,
  };
}
function assertSameIdentity(before,after) {
  for(const name of ["dbContainerId","dbContainerName","systemIdentifier","appContainerId","appImageId","appImageReference","origin"])
    assert.equal(after[name],before[name],`Unexpected changed runtime identity: ${name}`);
  assert.deepEqual(after.volume,before.volume,"Project-owned data volume changed");
}
async function waitUntilReady() {
  for(let n=0;n<30;n++) {
    const ready=run(`database-ready-${n+1}`,"docker",["exec",databaseContainer,"pg_isready","-U","postgres","-d",database],{allowNotReady:true});
    if(ready!==null) return;
    await new Promise((done)=>setTimeout(done,1000));
  }
  throw Error("Owned PostgreSQL did not become ready; use read-only reconciliation after inspecting it");
}
function releaseVerifiedRetainedLock() {
  const ownerPath=join(LOCK_PATH,"owner.json");
  const owner=readJson(ownerPath);
  assert.equal(owner.task,task);
  assert.equal(owner.runDirectory,dirname(original.receiptPath));
  assert.equal(hash(owner.token),original.lockOwnerTokenSha256);
  assert.deepEqual(readdirSync(LOCK_PATH),["owner.json"]);
  unlinkSync(ownerPath);
  rmdirSync(LOCK_PATH);
}
try {
  if(mode==="restart") {
    output=join(state,`persistence-${new Date().toISOString().replace(/[:.]/g,"-")}`);
    release=acquireLock({task,project,state,sourceSha:applicationSha,runDirectory:output,mode});
    assert(!existsSync(markerPath),"A restart was already requested; use reconcile with its preserved receipt instead");
    mkdirSync(output);
    receiptPath=join(output,"receipt.json");
    receipt={status:"started",mode,project,applicationSha,applicationTree,origin,receiptPath,startedAt:new Date().toISOString(),checks:[],browserState:"Caller asserts all browser profiles closed and no login jobs; shared guard held",paidModelCalls:0,lockOwnerTokenSha256:hash(readJson(join(LOCK_PATH,"owner.json")).token)};
    save();
    assert.equal(run("source-head","git",["-C",manifest.source,"rev-parse","HEAD"]),applicationSha);
    assert.equal(run("source-tree","git",["-C",manifest.source,"rev-parse","HEAD^{tree}"]),applicationTree);
    receipt.beforeIdentity=identity("before");
    receipt.before=fingerprint("before"); save();
    safe("single-owned-database-restart");
    receipt.restart={requestedAt:new Date().toISOString(),command:["docker","restart","--time","30",databaseContainer],scope:"Only this task's PostgreSQL container; app/gateway and original acceptance runtime are not restarted"};
    writeJson(markerPath,{receipt:receiptPath,applicationSha,project,requestedAt:receipt.restart.requestedAt},true);
    restartRequested=true; save();
    receipt.restart.acknowledgedContainer=run("single-owned-database-restart","docker",["restart","--time","30",databaseContainer]);
    receipt.restart.acknowledgedAt=new Date().toISOString(); save();
    await waitUntilReady();
    receipt.afterIdentity=identity("after");
    assertSameIdentity(receipt.beforeIdentity,receipt.afterIdentity);
    assert.notEqual(receipt.afterIdentity.dbStartedAt,receipt.beforeIdentity.dbStartedAt,"No database restart observed");
    assert(Date.parse(receipt.afterIdentity.dbStartedAt)>=Date.parse(receipt.restart.requestedAt)-1000,"Restart timestamp predates request");
    receipt.after=fingerprint("after");
    assert.deepEqual(receipt.after,receipt.before,"Persisted table rows changed across the owned database restart");
  } else {
    const priorPath=resolve(args[0]);
    assert(priorPath.startsWith(`${resolve(state)}\\`) || priorPath.startsWith(`${resolve(state)}/`),"Reconciliation receipt must be inside this owned runtime");
    original=readJson(priorPath);
    assert.equal(original.project,project);
    assert.equal(original.applicationSha,applicationSha);
    assert.equal(original.applicationTree,applicationTree);
    assert.equal(resolve(original.receiptPath),priorPath);
    assert(original.beforeIdentity&&original.before&&original.restart?.requestedAt,"No preserved pre-restart snapshot/request to reconcile");
    assert.equal(resolve(readJson(markerPath).receipt),priorPath);
    if(existsSync(LOCK_PATH)) {
      const owner=readJson(join(LOCK_PATH,"owner.json"));
      assert.equal(owner.task,task);
      assert.equal(owner.project,project);
      assert.equal(owner.runDirectory,dirname(priorPath));
      assert.equal(hash(owner.token),original.lockOwnerTokenSha256);
      let alive=true;
      try{process.kill(owner.pid,0);}catch(error){if(error.code==="ESRCH")alive=false;else throw Error("Could not establish prior owner process exit; do not reconcile concurrently");}
      assert(!alive,"Prior persistence process still exists; wait for it before reconciliation");
      usingRetainedLock=true;
    } else release=acquireLock({task,project,state,sourceSha:applicationSha,mode:"read-only reconciliation",originalReceipt:priorPath});
    output=join(state,`persistence-reconcile-${new Date().toISOString().replace(/[:.]/g,"-")}`);mkdirSync(output);
    receiptPath=join(output,"receipt.json");
    receipt={status:"started",mode,project,applicationSha,applicationTree,origin,receiptPath,originalReceipt:priorPath,originalReceiptSha256:hash(readFileSync(priorPath)),startedAt:new Date().toISOString(),checks:[],paidModelCalls:0,restartCommands:0,browserState:"Caller asserts all browser profiles closed; retained or new owned guard verified"};save();
    await waitUntilReady();
    receipt.currentIdentity=identity("reconcile");
    assertSameIdentity(original.beforeIdentity,receipt.currentIdentity);
    assert.notEqual(receipt.currentIdentity.dbStartedAt,original.beforeIdentity.dbStartedAt,"Requested restart has not been observed; reconciliation cannot replay it");
    assert(Date.parse(receipt.currentIdentity.dbStartedAt)>=Date.parse(original.restart.requestedAt)-1000);
    receipt.current=fingerprint("reconcile");
    assert.deepEqual(receipt.current,original.before,"Current table rows differ from pre-restart snapshot");
  }
  receipt.status="pass";receipt.finishedAt=new Date().toISOString();save();
  completed=true;
  console.log(JSON.stringify({status:"pass",mode,receipt:receiptPath,tables:(receipt.after??receipt.current).tables.length,additionalRestarts:mode==="restart"?1:0}));
} catch(error) {
  if(receipt){receipt.status="fail";receipt.error=String(error.message);receipt.lockRetainedForReconciliation=(restartRequested||usingRetainedLock)&&!completed;save();}
  console.error(`Persistence verification stopped: ${error.message}. No automatic restart retry will occur.`);
  process.exitCode=1;
} finally {
  if(completed&&usingRetainedLock)releaseVerifiedRetainedLock();
  else if(completed||(!restartRequested&&!usingRetainedLock))release?.();
}
