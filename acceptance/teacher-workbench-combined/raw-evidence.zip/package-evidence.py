"""Allowlisted publication; invoke through publish-evidence.mjs after runtime work.

Original evidence is read only. Selected text derivatives redact only ended local
coordination-lock tokens; any actual credential finding stops publication.
"""
from __future__ import annotations

import argparse
import hashlib
import html
from html.parser import HTMLParser
import json
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess
import sys
from datetime import datetime, timezone
from urllib.parse import unquote, urlsplit
from uuid import uuid4
import zipfile

ROOT = Path("C:/Users/sb128/.codex/visualizations/2026/10/25/01a174be-f6b2-7012-b723-c460b8858df5")
VERIFICATION = ROOT / "verification"
RUNTIME = ROOT / "runtime"
DESTINATION = Path("C:/Users/sb128/.codex/worktrees/teacher-workbench-combined/LearningPlatform/acceptance/teacher-workbench-combined")
APPLICATION = DESTINATION.parent.parent
LOCK = Path("C:/Users/sb128/AppData/Local/learning-pulse-acceptance.lock")
SHA = "c26664e49b7cc15fa7c63828f5c582c9b8cac2d8"
TREE = "333b73e1cae1daddf6edd61300655d0b4825ed67"
TEXT = {".json", ".log", ".txt", ".md", ".mjs", ".cjs", ".py", ".html", ".sql", ".patch"}
VERIFICATION_DIRECTORIES = re.compile(r"^(?:composition|journey-bundle|visual-bundle|(?:application|prototype|evidence|hydration|navigation|r03-labels|returns|structure-handoffs|recovery|new-intervention-[a-z-]+|intervention-[a-z-]+|final-persistence)-\d+)$")
PRIVATE_DIRECTORY = re.compile(r"(?:^\.|profile|cache|node_modules|recomposition\.git|vendor|export)", re.I)
RUNTIME_DIRECTORY = re.compile(r"^(?:clone-original|port-correction|persistence(?:-reconcile)?)-[0-9TZ.-]+$")
SENSITIVE_KEYS = re.compile(r"^(?:password|token|secret|authorization|cookie|set-cookie|accessToken|refreshToken|idToken|AUTH_SECRET|PGPASSWORD|POSTGRES_PASSWORD|DEMO_.+_PASSWORD|OPENAI_API_KEY)$", re.I)
ENV_SECRET_KEYS = re.compile(r"(?:PASSWORD|SECRET|API_KEY|ACCESS_TOKEN|REFRESH_TOKEN)", re.I)
PUBLISHED_SUFFIXES = {".md", ".json", ".html", ".png"}
PUBLISHED_TEXT = {"review.txt", "BROWSER_COMMANDS.txt", "STRUCTURE_HANDOFF_COMMANDS.txt", "composition/REPORT.txt"}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def json_bytes(value: object) -> bytes:
    return (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode("utf-8")


def walk_allowed(directory: Path):
    for base, dirs, files in os.walk(directory, followlinks=False):
        dirs[:] = sorted(name for name in dirs if not PRIVATE_DIRECTORY.search(name)
                         and not (Path(base) / name).is_symlink()
                         and not getattr(Path(base) / name, "is_junction", lambda: False)())
        for name in sorted(files):
            path = Path(base) / name
            if path.is_symlink() or ".private" in name or name.startswith(".env"):
                continue
            if path.suffix.lower() in TEXT | {".png"}:
                yield path


def selections(report_path: Path):
    chosen: dict[str, Path] = {}
    for entry in sorted(VERIFICATION.iterdir()):
        if entry.is_file() and entry.suffix.lower() in TEXT and not entry.name.startswith(".env"):
            chosen[entry.name] = entry
        elif entry.is_dir() and VERIFICATION_DIRECTORIES.fullmatch(entry.name):
            for path in walk_allowed(entry):
                chosen[path.relative_to(VERIFICATION).as_posix()] = path
    for path in sorted((RUNTIME / "runs").glob("*/*")):
        if path.is_file() and path.suffix in {".json", ".log"}:
            chosen["runtime/" + path.relative_to(RUNTIME).as_posix()] = path
    for entry in sorted(RUNTIME.iterdir()):
        if entry.is_dir() and RUNTIME_DIRECTORY.fullmatch(entry.name):
            for path in sorted(entry.iterdir()):
                if path.is_file() and path.suffix in {".json", ".log", ".txt"} and ".private" not in path.name:
                    chosen["runtime/" + path.relative_to(RUNTIME).as_posix()] = path
    for name in ["manifest.json", "original-fixture-clone-completed.json", "persistence-restart-requested.json"]:
        path = RUNTIME / name
        if path.is_file():
            chosen["runtime/" + name] = path
    chosen["REPORT.md"] = report_path
    return chosen


def known_secrets() -> set[bytes]:
    # Values stay in memory and never appear in a report or exception.
    paths = [RUNTIME / ".env.acceptance",
             Path("C:/Users/sb128/.codex/visualizations/2026/10/25/01a173d6-e789-7233-92d2-b0b55d4559ed/runtime-final/.env.acceptance")]
    paths += list(RUNTIME.glob("clone-original-*/.env.target-before.private"))
    paths += list(RUNTIME.glob("port-correction-*/env.before.private"))
    values = set()
    for path in paths:
        if not path.is_file():
            continue
        for line in path.read_text(encoding="utf-8-sig").splitlines():
            if "=" not in line or line.lstrip().startswith("#"):
                continue
            key, value = line.split("=", 1)
            if ENV_SECRET_KEYS.search(key) and len(value) >= 6:
                values.add(value.encode())
    assert values, "Expected local credentials to be available for exact-value exclusion checks"
    return values


def sanitize_json(value, path=(), redactions=None):
    if redactions is None:
        redactions = []
    if isinstance(value, dict):
        output = {}
        for key, item in value.items():
            pointer = path + (str(key),)
            if key == "token" and path and path[-1] in {"lockOwner", "lock_owner", "owner"} and isinstance(item, str):
                if not re.fullmatch(r"[a-f0-9-]{36}", item, re.I):
                    raise ValueError("Unexpected coordination token shape at " + "/".join(pointer))
                output[key] = "[REDACTED local coordination lock token]"
                redactions.append({"path": "/" + "/".join(pointer), "valueSha256": digest(item.encode()), "reason": "Local coordination capability; original retained privately"})
            elif SENSITIVE_KEYS.fullmatch(str(key)) and isinstance(item, str) and item:
                if not (item.startswith("[REDACTED") or re.fullmatch(r"\$\{[A-Z0-9_]+\}", item)):
                    raise ValueError("Potential credential in JSON at " + "/".join(pointer))
                output[key] = item
            else:
                output[key] = sanitize_json(item, pointer, redactions)
        return output
    if isinstance(value, list):
        return [sanitize_json(item, path + (str(index),), redactions) for index, item in enumerate(value)]
    return value


class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []

    def handle_starttag(self, tag, attrs):
        for key, value in attrs:
            if key in {"href", "src"} and value:
                self.links.append((tag, value))


def verify_gallery_links(stage: Path) -> list[dict]:
    galleries = sorted(path for path in stage.rglob("*.html") if "gallery" in path.name.lower() or "comparison" in path.name.lower())
    assert galleries, "A paired prototype/application comparison gallery is required before publication"
    receipts = []
    for path in galleries:
        parser = Links()
        parser.feed(path.read_text(encoding="utf-8"))
        local_count = 0
        image_count = 0
        for tag, link in parser.links:
            parsed = urlsplit(html.unescape(link))
            if parsed.scheme in {"https", "http", "mailto", "data"} or not parsed.path:
                continue
            assert not parsed.scheme and not parsed.netloc, "Unsupported gallery link scheme"
            resolved = (path.parent / unquote(parsed.path)).resolve()
            assert resolved.is_relative_to(stage.resolve()), "Gallery link leaves publication package"
            assert resolved.is_file(), "Missing gallery target: " + parsed.path
            local_count += 1
            image_count += tag == "img"
        assert image_count, "Comparison gallery contains no image references"
        receipts.append({"gallery": path.relative_to(stage).as_posix(), "verifiedLocalLinks": local_count, "imageReferences": image_count})
    return receipts


def format_published(paths: list[Path]):
    """Format only publication derivatives with the existing repository tool."""
    prettier = APPLICATION / "node_modules/prettier/bin/prettier.cjs"
    config = APPLICATION / ".prettierrc.json"
    assert prettier.is_file() and config.is_file(), "Existing repository Prettier is required"
    for start in range(0, len(paths), 20):
        selected = paths[start:start + 20]
        result = subprocess.run(["node", str(prettier), "--config", str(config), "--ignore-path",
                                 str(APPLICATION / ".prettierignore"), "--write", *map(str, selected)],
                                cwd=APPLICATION, capture_output=True, text=True, timeout=90,
                                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        assert result.returncode == 0, "Existing Prettier failed for publication derivatives; staging preserved"


def verify_report_links(stage: Path) -> list[dict]:
    receipts = []
    for path in sorted(stage.rglob("*.md")):
        count = 0
        for match in re.finditer(r"!?\[[^\]]*\]\((<[^>]+>|[^)\s]+)(?:\s+\"[^\"]*\")?\)", path.read_text(encoding="utf-8")):
            link = match.group(1).strip("<>")
            parsed = urlsplit(html.unescape(link))
            if parsed.scheme in {"https", "http", "mailto"} or not parsed.path:
                continue
            assert not parsed.scheme and not parsed.netloc, "Unsupported report link scheme"
            resolved = (path.parent / unquote(parsed.path)).resolve()
            assert resolved.is_relative_to(stage.resolve()), "Report link leaves publication package"
            assert resolved.exists(), "Missing report link: " + path.relative_to(stage).as_posix() + " -> " + parsed.path
            count += 1
        receipts.append({"report": path.relative_to(stage).as_posix(), "verifiedLocalLinks": count})
    return receipts


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--publish", action="store_true")
    parser.add_argument("--report", type=Path, default=VERIFICATION / "REPORT.md")
    args = parser.parse_args()
    if not args.publish:
        print("Prepared only. Invoke publish-evidence.mjs --publish after runtime work and root REPORT.md are complete.")
        return
    owner = json.loads((LOCK / "owner.json").read_text())
    assert owner.get("task") == "publish teacher combined evidence" and owner.get("project") == "lp-teacher-combined-01a174be", "Run through the reviewed guard wrapper"
    manifest = json.loads((RUNTIME / "manifest.json").read_text())
    assert manifest["sourceSha"] == SHA and manifest["sourceTree"] == TREE and manifest["origin"] == "http://localhost:3449"
    report_path = args.report.resolve()
    assert report_path.is_file() and (report_path.is_relative_to(ROOT.resolve()) or report_path == (DESTINATION / "REPORT.md").resolve())
    chosen = selections(report_path)
    assert "SOURCE_MATRIX.json" in chosen and SHA in chosen["SOURCE_MATRIX.json"].read_text(), "Exact source matrix missing"
    assert not (DESTINATION / "MANIFEST.json").exists(), "Existing publication must be preserved; no overwrite/republication"
    if DESTINATION.exists():
        assert set(path.relative_to(DESTINATION).as_posix() for path in DESTINATION.rglob("*") if path.is_file()) <= {"REPORT.md"}, "Unexpected existing publication files"
        if (DESTINATION / "REPORT.md").exists():
            assert (DESTINATION / "REPORT.md").read_bytes() == report_path.read_bytes()
    secret_values = known_secrets()
    stage = VERIFICATION / ("publication-stage-" + uuid4().hex)
    stage.mkdir()
    file_records = []
    redaction_files = []
    archive_content = {}
    for destination_name, source_path in sorted(chosen.items()):
        original = source_path.read_bytes()
        published = original
        redactions = []
        if source_path.suffix.lower() == ".json":
            value = json.loads(original.decode("utf-8-sig"))
            clean = sanitize_json(value, redactions=redactions)
            if redactions:
                published = json_bytes(clean)
        for secret in secret_values:
            if secret in published:
                raise ValueError("Exact local credential detected in " + destination_name + "; source and staging preserved, no publication performed")
        if source_path.suffix.lower() in TEXT:
            text = published.decode("utf-8-sig")
            if re.search(r"(?:sk-(?:proj-)?[A-Za-z0-9_-]{24,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)", text):
                raise ValueError("Potential key material detected in " + destination_name)
        png = None
        if source_path.suffix.lower() == ".png":
            assert original[:8] == b"\x89PNG\r\n\x1a\n", "Invalid PNG signature"
            width, height = struct.unpack(">II", original[16:24])
            assert width > 0 and height > 0
            png = {"width": width, "height": height, "pixelsModified": False}
        # Raw archive bytes retain original formatting. Only explicitly recorded
        # local lock-token redactions may change their content.
        raw_derivative = published
        archived = source_path.suffix.lower() in TEXT
        publish_file = source_path.suffix.lower() in PUBLISHED_SUFFIXES or destination_name in PUBLISHED_TEXT
        if archived:
            archive_content[destination_name] = raw_derivative
        if publish_file:
            destination = stage / destination_name
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(raw_derivative)
        record = {"path": destination_name, "sourcePath": str(source_path), "sourceSha256": digest(original),
                  "sourceBytes": len(original), "archived": archived, "published": publish_file,
                  "archiveSha256": digest(raw_derivative) if archived else None,
                  "archiveByteIdentical": original == raw_derivative if archived else None}
        if png:
            record["png"] = png
        if redactions:
            record["redactions"] = redactions
            redaction_files.append(destination_name)
        file_records.append(record)
    format_published(sorted(path for path in stage.rglob("*") if path.suffix in {".md", ".json", ".html"}))
    for record in file_records:
        if record["published"]:
            final_bytes = (stage / record["path"]).read_bytes()
            record.update(publishedSha256=digest(final_bytes), publishedBytes=len(final_bytes),
                          publishedByteIdentical=record["sourceSha256"] == digest(final_bytes),
                          publishedFormatting="Existing repository Prettier" if Path(record["path"]).suffix in {".md", ".json", ".html"} else "Byte-preserved")
    links = verify_gallery_links(stage)
    archive_path = stage / "raw-evidence.zip"
    archive_members = []
    with zipfile.ZipFile(archive_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for record in file_records:
            if not record["archived"]:
                continue
            info = zipfile.ZipInfo(record["path"], date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, archive_content[record["path"]], compresslevel=6)
            archive_members.append({"path": record["path"], "sourceSha256": record["sourceSha256"], "sha256": record["archiveSha256"], "byteIdenticalToOriginal": record["archiveByteIdentical"]})
    with zipfile.ZipFile(archive_path) as archive:
        assert archive.testzip() is None
        for entry in archive_members:
            assert digest(archive.read(entry["path"])) == entry["sha256"]
    publication = {
        "applicationSha": SHA, "applicationTree": TREE, "createdAt": datetime.now(timezone.utc).isoformat(),
        "files": file_records, "archive": {"path": "raw-evidence.zip", "sha256": digest(archive_path.read_bytes()), "bytes": archive_path.stat().st_size, "members": archive_members},
        "exclusions": ["All environment/secret files and backups", "Browser profiles, caches, cookies and storage", "Raw database dumps", "Git recomposition repository/index", "Dependencies and compiled output", "Approved prototype vendor HTML/export (only rendered comparisons retained)", "Runtime compose and private configuration"],
        "redactedDerivatives": redaction_files,
        "preservation": "Original artifacts unchanged. Archive preserves raw text bytes except explicit local-lock-token redactions. Published MD/JSON/HTML are formatted derivatives with separate hashes. Screenshots are byte-identical. Historical and failed receipts remain failed.",
        "repositoryPolicy": "Scripts, SQL, patches and raw logs exist only inside raw-evidence.zip; no lint/format exclusions are introduced.",
    }
    (stage / "MANIFEST.json").write_bytes(json_bytes(publication))
    format_published([stage / "MANIFEST.json"])
    validation = {"status": "pass", "files": len(file_records), "publishedFiles": sum(record["published"] for record in file_records), "originalBytes": sum(record["sourceBytes"] for record in file_records), "screenshots": sum("png" in record for record in file_records), "redactedDerivatives": len(redaction_files), "exactCredentialScan": "pass; values never emitted", "genericJsonCredentialScan": "pass", "archiveMembers": len(archive_members), "archiveHashVerified": True, "galleryLinks": links, "reportLinks": [], "manifestSha256": digest((stage / "MANIFEST.json").read_bytes()), "publishedFormatting": "Existing repository Prettier; final hashes computed afterward", "applicationAcceptance": "Not established by packaging; see root report and independent acceptance handoff"}
    (stage / "PUBLICATION_VALIDATION.json").write_bytes(json_bytes(validation))
    validation["reportLinks"] = verify_report_links(stage)
    (stage / "PUBLICATION_VALIDATION.json").write_bytes(json_bytes(validation))
    format_published([stage / "PUBLICATION_VALIDATION.json"])
    assert not any(path.suffix in {".mjs", ".cjs", ".py", ".sql", ".patch", ".log"} for path in stage.rglob("*")), "Raw executable or log escaped the archive"
    # Validate all sources are still exactly the bytes reviewed above before copying.
    for record in file_records:
        assert digest(Path(record["sourcePath"]).read_bytes()) == record["sourceSha256"], "Source changed during packaging"
    DESTINATION.mkdir(parents=True, exist_ok=True)
    for path in sorted(stage.rglob("*")):
        if not path.is_file():
            continue
        destination = DESTINATION / path.relative_to(stage)
        if destination.exists():
            assert destination.name == "REPORT.md" and destination.read_bytes() == report_path.read_bytes()
            # Root explicitly authorizes formatting this publication report.
            # Its exact pre-format bytes remain in the raw archive.
            destination.write_bytes(path.read_bytes())
            continue
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open("xb") as stream:
            stream.write(path.read_bytes())
        assert digest(destination.read_bytes()) == digest(path.read_bytes())
    print(json.dumps({"status": "published locally, not committed", "destination": str(DESTINATION), "stagingRetained": str(stage), **validation}, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print("Publication stopped: " + str(error), file=sys.stderr)
        raise SystemExit(1)
