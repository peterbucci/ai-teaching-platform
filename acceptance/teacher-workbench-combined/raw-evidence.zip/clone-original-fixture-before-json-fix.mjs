// Verification-only clone. Does not run without the explicit --execute argument.
// Source access is read-only; restoration is restricted to this task's owned DB.
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import {
  existsSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  renameSync,
  writeFileSync,
} from "node:fs";
import { join, resolve } from "node:path";
import { acquireLock, preflight, MIN_RUNTIME_GIB } from "./safety.mjs";

const root = "C:/Users/sb128/.codex/visualizations/2026/10/25/01a174be-f6b2-7012-b723-c460b8858df5";
const state = join(root, "runtime");
const originalState = "C:/Users/sb128/.codex/visualizations/2026/10/25/01a173d6-e789-7233-92d2-b0b55d4559ed/runtime-final";
const targetProject = "lp-teacher-combined-01a174be";
const originalProject = "lp-v22-final-01a173d6";
const applicationSha = "c26664e49b7cc15fa7c63828f5c582c9b8cac2d8";
const applicationTree = "333b73e1cae1daddf6edd61300655d0b4825ed67";
const originalSha = "07efb7f821339538800f150f57b298eb2e606be3";
const originalTree = "948b9a6005a056c97f10d181c589b5352d6221f3";
const targetDb = `${targetProject}-db-1`;
const originalDb = `${originalProject}-db-1`;
const database = "learning_platform";
const demoKeys = [
  "DEMO_TEACHER_EMAIL", "DEMO_TEACHER_PASSWORD",
  "DEMO_STUDENT_ONE_EMAIL", "DEMO_STUDENT_ONE_PASSWORD",
  "DEMO_STUDENT_TWO_EMAIL", "DEMO_STUDENT_TWO_PASSWORD",
];
const sha256 = (value) => createHash("sha256").update(value).digest("hex");
const json = (path) => JSON.parse(readFileSync(path, "utf8"));
const envFile = (path) => Object.fromEntries(readFileSync(path, "utf8").split(/\r?\n/).filter((line) => line && !line.startsWith("#")).map((line) => {
  const split = line.indexOf("=");
  assert(split > 0, "Malformed environment file");
  return [line.slice(0, split), line.slice(split + 1)];
}));
if (process.argv.length !== 3 || process.argv[2] !== "--execute") {
  console.log("Prepared clone helper; no actions executed. Review source, then run with --execute under the task's runtime authorization.");
  process.exit(0);
}
const manifest = json(join(state, "manifest.json"));
const originalManifest = json(join(originalState, "manifest.json"));
assert.equal(manifest.project, targetProject);
assert.equal(manifest.sourceSha, applicationSha);
assert.equal(manifest.sourceTree, applicationTree);
assert.equal(manifest.origin, "http://localhost:3449");
assert.equal(originalManifest.project, originalProject);
assert.equal(originalManifest.sourceSha, originalSha);
assert.equal(originalManifest.sourceTree, originalTree);
assert.notEqual(resolve(state), resolve(originalState));
assert.equal(sha256(readFileSync(new URL("./safety.mjs", import.meta.url))), "af01b05dd317682a47b6ec64acc5083cae1430383d697dcb1ede53687722c485");
const targetEnvPath = join(state, ".env.acceptance");
const sourceEnvPath = join(originalState, ".env.acceptance");
const targetEnvironment = envFile(targetEnvPath);
const sourceEnvironment = envFile(sourceEnvPath);
const commandEnvironment = {...process.env, ...targetEnvironment};
delete commandEnvironment.COMPOSE_FILE;
delete commandEnvironment.COMPOSE_PROJECT_NAME;
delete commandEnvironment.DATABASE_URL;
for (const environment of [targetEnvironment, sourceEnvironment]) {
  assert.equal(environment.OPENAI_API_KEY, "");
  assert.equal(environment.OPENAI_MODEL, "");
}
assert.equal(targetEnvironment.AUTH_URL, manifest.origin);
for (const key of demoKeys) {
  assert(sourceEnvironment[key], `Missing original ${key}`);
  if (key.endsWith("EMAIL")) assert(sourceEnvironment[key].endsWith("@example.invalid"), "Refusing non-fictional demo account domain");
}
assert(!existsSync(join(state, "original-fixture-clone-completed.json")), "Clone already completed; do not overwrite newer work");
for (const name of readdirSync(join(state, "runs"))) {
  const reportPath = join(state, "runs", name, "results.json");
  if (!existsSync(reportPath)) continue;
  const prior = json(reportPath);
  assert(!["integration", "approval"].includes(prior.mode), "Runtime already has service-test evidence; inspect and preserve it before choosing a separate clone state");
}
const runDirectory = join(state, `clone-original-${new Date().toISOString().replace(/[:.]/g, "-")}`);
mkdirSync(runDirectory);
const receiptPath = join(runDirectory, "receipt.json");
const receipt = {
  status: "started", source: { project: originalProject, container: originalDb, applicationSha: originalSha },
  target: { project: targetProject, container: targetDb, applicationSha, applicationTree },
  preservation: {}, checks: [], paidModelCalls: 0, startedAt: new Date().toISOString(),
  privateArtifacts: ["source.private.dump", "target-before.private.dump", ".env.target-before.private"],
};
const save = () => writeFileSync(receiptPath, `${JSON.stringify(receipt, null, 2)}\n`);
const secretValues = [...Object.entries(sourceEnvironment), ...Object.entries(targetEnvironment)]
  .filter(([key, value]) => /PASSWORD|SECRET|KEY/.test(key) && value).map(([, value]) => value);
const redact = (value) => secretValues.reduce((text, secret) => text.replaceAll(secret, "[REDACTED]"), String(value ?? ""));
let release;
let targetMutationStarted = false;
let completed = false;
const safe = (name) => {
  const observation = preflight({source: manifest.source, state, minimumGiB: MIN_RUNTIME_GIB, explicitPath: manifest.dockerDataPath, probeContainer: originalDb});
  receipt.checks.push({name: `preflight:${name}`, ...observation});
  save();
  assert(observation.pass, `Storage preflight failed before ${name}`);
};
const run = (name, command, args, options = {}) => {
  safe(name);
  const result = spawnSync(command, args, {encoding: "utf8", windowsHide: true, env:commandEnvironment, maxBuffer: 256 * 1024 * 1024, timeout: 120_000, ...options});
  receipt.checks.push({name, pass: result.status === 0 && !result.error, exitCode: result.status, finishedAt: new Date().toISOString()});
  save();
  if (result.status !== 0 || result.error) {
    writeFileSync(join(runDirectory, `${name}.failure.txt`), redact(result.stderr) + "\n" + redact(result.error?.message));
    throw Error(`${name} failed; inspect retained private runtime receipt; no automatic retry`);
  }
  return result.stdout;
};
const inspect = (container) => JSON.parse(run(`inspect-${container}`, "docker", ["container", "inspect", container]))[0];
const validateDb = (info, project) => {
  assert.equal(info.Name, `/${project}-db-1`);
  assert.equal(info.Config.Labels["com.docker.compose.project"], project);
  assert.equal(info.Config.Labels["com.docker.compose.service"], "db");
  assert(info.State.Running);
  assert(info.Mounts.some((mount) => mount.Type === "volume" && mount.Name === `${project}_postgres_data` && mount.Destination === "/var/lib/postgresql/data"));
};
const readQuery = (container, name, sql) => run(name, "docker", ["exec", "-e", "PGOPTIONS=-c default_transaction_read_only=on", container, "psql", "-X", "-U", "postgres", "-d", database, "-At", "-v", "ON_ERROR_STOP=1", "-c", sql]).trim();
const fingerprint = (container, label) => {
  const names = readQuery(container, `${label}-tables`, "SELECT tablename FROM pg_tables WHERE schemaname='public' ORDER BY tablename").split(/\r?\n/).filter(Boolean);
  assert(names.length > 20, "Expected populated application schema");
  const queries = names.map((name) => {
    assert(/^[a-z_][a-z0-9_]*$/.test(name), "Unexpected table identifier");
    return `SELECT '${name}' AS name, count(*)::text AS count, md5(coalesce(string_agg(row_to_json(t)::text, E'\\n' ORDER BY row_to_json(t)::text), '')) AS fingerprint FROM "${name}" t`;
  });
  const raw = readQuery(container, `${label}-fingerprints`, `BEGIN READ ONLY; SELECT json_agg(f ORDER BY name) FROM (${queries.join(" UNION ALL ")}) f; COMMIT;`);
  const line = raw.split(/\r?\n/).find((row) => row.startsWith("["));
  assert(line, "Missing table fingerprint response");
  return JSON.parse(line).map((entry) => ({...entry, count:Number(entry.count)}));
};
const composeArgs = ["compose", "--project-name", targetProject, "--env-file", targetEnvPath, "--file", join(state, "compose.json")];
try {
  release = acquireLock({task: "final teacher combined original fixture clone", source: manifest.source, state, project: targetProject, sourceSha: applicationSha});
  const sourceEnvHash = sha256(readFileSync(sourceEnvPath));
  const configHash = sha256(readFileSync(join(state, "compose.json")));
  const sourceInfo = inspect(originalDb);
  const targetInfo = inspect(targetDb);
  validateDb(sourceInfo, originalProject);
  validateDb(targetInfo, targetProject);
  assert.notEqual(sourceInfo.Id, targetInfo.Id);
  receipt.source.containerId = sourceInfo.Id;
  receipt.target.containerId = targetInfo.Id;
  receipt.source.systemIdentifier = readQuery(originalDb, "source-system-identifier", "SELECT system_identifier FROM pg_control_system()");
  receipt.target.systemIdentifier = readQuery(targetDb, "target-system-identifier", "SELECT system_identifier FROM pg_control_system()");
  assert.notEqual(receipt.source.systemIdentifier, receipt.target.systemIdentifier, "Target must be separate PostgreSQL cluster");
  receipt.target.ownership = JSON.parse(readQuery(targetDb, "target-restore-ownership", `SELECT json_build_object(
    'databaseOwner', (SELECT pg_get_userbyid(datdba) FROM pg_database WHERE datname=current_database()),
    'publicSchemaOwner', (SELECT pg_get_userbyid(nspowner) FROM pg_namespace WHERE nspname='public'),
    'publicSchemaUsable', has_schema_privilege('learning_app','public','USAGE,CREATE'),
    'otherTableOwners', (SELECT count(*) FROM pg_tables WHERE schemaname='public' AND tableowner<>'learning_app'))`));
  assert.equal(receipt.target.ownership.databaseOwner, "learning_app", "Target database not owned by application role");
  assert(["learning_app", "pg_database_owner"].includes(receipt.target.ownership.publicSchemaOwner), "Unexpected public schema owner; do not start restore");
  assert.equal(receipt.target.ownership.publicSchemaUsable, true);
  assert.equal(receipt.target.ownership.otherTableOwners, 0, "Existing target tables have another owner; do not start restore");
  const appInfo = inspect(`${targetProject}-app-1`);
  assert.equal(appInfo.Config.Labels["com.docker.compose.project"], targetProject);
  assert.equal(appInfo.Config.Image, `${targetProject}:${applicationSha}`);
  const config = json(join(state, "compose.json"));
  assert.equal(config.services.app.image, `${targetProject}:${applicationSha}`);
  assert.equal(resolve(config.services.app.build.context), resolve(manifest.source));
  assert.equal(config.networks.acceptance.internal, true);
  assert.deepEqual(config.services.gateway.ports, ["127.0.0.1:3449:80"]);
  for (const key of demoKeys) assert.equal(config.services.app.environment[key], `\${${key}}`);
  receipt.source.before = fingerprint(originalDb, "source-before");
  receipt.target.before = fingerprint(targetDb, "target-before");
  const dump = run("read-only-source-dump", "docker", ["exec", "-e", "PGOPTIONS=-c default_transaction_read_only=on", originalDb, "pg_dump", "-U", "postgres", "-d", database, "--format=custom", "--no-owner", "--no-privileges"], {encoding:null});
  assert(Buffer.isBuffer(dump) && dump.subarray(0,5).toString() === "PGDMP");
  writeFileSync(join(runDirectory, "source.private.dump"), dump, {flag:"wx", mode:0o600});
  receipt.source.dumpSha256 = sha256(dump);
  const targetBackup = run("read-only-target-backup", "docker", ["exec", "-e", "PGOPTIONS=-c default_transaction_read_only=on", targetDb, "pg_dump", "-U", "postgres", "-d", database, "--format=custom", "--no-owner", "--no-privileges"], {encoding:null});
  writeFileSync(join(runDirectory, "target-before.private.dump"), targetBackup, {flag:"wx", mode:0o600});
  receipt.target.beforeDumpSha256 = sha256(targetBackup);
  writeFileSync(join(runDirectory, ".env.target-before.private"), readFileSync(targetEnvPath), {flag:"wx", mode:0o600});
  targetMutationStarted = true;
  run("stop-owned-application", "docker", [...composeArgs, "stop", "app"]);
  // Only the explicitly pinned target receives writes; source name cannot enter this call.
  assert.equal(targetDb, "lp-teacher-combined-01a174be-db-1");
  assert.notEqual(targetDb, originalDb);
  run("restore-owned-target-once", "docker", ["exec", "-i", targetDb, "pg_restore", "-U", "postgres", "--role=learning_app", "-d", database, "--clean", "--if-exists", "--single-transaction", "--exit-on-error", "--no-owner", "--no-privileges"], {input:dump});
  receipt.target.afterRestore = fingerprint(targetDb, "target-after-restore");
  assert.deepEqual(receipt.target.afterRestore, receipt.source.before, "Cloned table fingerprints differ from original source");
  const updated = {...targetEnvironment};
  for (const key of demoKeys) updated[key] = sourceEnvironment[key];
  for (const [key, value] of Object.entries(targetEnvironment)) if (!demoKeys.includes(key)) assert.equal(updated[key], value);
  const pendingEnvPath = `${targetEnvPath}.clone-pending`;
  writeFileSync(pendingEnvPath, `${Object.entries(updated).map(([key,value]) => `${key}=${value}`).join("\n")}\n`, {flag:"wx", mode:0o600});
  renameSync(pendingEnvPath, targetEnvPath);
  Object.assign(commandEnvironment, updated);
  assert.equal(sha256(readFileSync(join(state, "compose.json"))), configHash, "Compose configuration changed");
  receipt.preservation.copiedEnvironmentKeys = demoKeys;
  receipt.preservation.targetDatabaseAndAuthSecretsPreserved = true;
  receipt.preservation.providersDisabled = !updated.OPENAI_API_KEY && !updated.OPENAI_MODEL;
  run("recreate-owned-app-with-original-demo-logins", "docker", [...composeArgs, "up", "--detach", "--no-build", "--force-recreate", "--wait", "--wait-timeout", "180", "app"]);
  run("reload-owned-gateway", "docker", [...composeArgs, "exec", "-T", "gateway", "nginx", "-s", "reload"]);
  receipt.target.afterStart = fingerprint(targetDb, "target-after-start");
  assert.deepEqual(receipt.target.afterStart, receipt.source.before, "Application startup changed cloned records");
  receipt.source.after = fingerprint(originalDb, "source-after");
  assert.deepEqual(receipt.source.after, receipt.source.before, "Original records changed during clone; reconcile before claiming preservation");
  assert.equal(sha256(readFileSync(sourceEnvPath)), sourceEnvHash);
  receipt.preservation.originalSourceUnchanged = true;
  receipt.status = "pass";
  receipt.finishedAt = new Date().toISOString();
  save();
  writeFileSync(join(state, "original-fixture-clone-completed.json"), `${JSON.stringify({receipt:receiptPath, sourceSha:originalSha, targetSha:applicationSha, dumpSha256:receipt.source.dumpSha256, completedAt:receipt.finishedAt},null,2)}\n`, {flag:"wx"});
  completed = true;
  console.log(JSON.stringify({status:"pass", receipt:receiptPath, tables:receipt.source.before.length, targetProject, providersDisabled:true}));
} catch(error) {
  receipt.status = "fail";
  receipt.error = redact(error.message);
  receipt.targetMutationStarted = targetMutationStarted;
  receipt.lockRetainedForReconciliation = targetMutationStarted && !completed;
  save();
  console.error(`Clone stopped: ${receipt.error}. ${receipt.lockRetainedForReconciliation ? "Owned lock retained; reconcile saved target state before any retry." : "No target mutation began."}`);
  process.exitCode = 1;
} finally {
  if (completed || !targetMutationStarted) release?.();
}
