import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const base='verification/journey-bundle/combined-structure-handoffs.mjs';
const original=readFileSync(base,'utf8');
const next=original.replace("page.locator('.wb-original').textContent()", "page.getByRole('heading',{name:'Original question',exact:true}).locator('+ p.wb-original').textContent()").replace("page.locator('.awa-page-heading .awa-eyebrow').innerText()", "page.locator('.awa-page-heading .awa-eyebrow').textContent()");
if(next===original)throw new Error('No patch');
writeFileSync('verification/journey-bundle/combined-structure-handoffs-v2.mjs',next);
const hash=t=>createHash('sha256').update(t).digest('hex');
writeFileSync('verification/STRUCTURE_HANDOFF_REVISION_02.json',JSON.stringify({original:base,originalSha256:hash(original),updated:'journey-bundle/combined-structure-handoffs-v2.mjs',updatedSha256:hash(next),retainedFailure:'structure-handoffs-01/report.json',changes:['Scope original question to heading-adjacent paragraph; wb-original is also used for evaluator reasoning. Exact equality to saved question retained.','Use raw textContent for assignment title comparison; CSS text-transform uppercase changes innerText while source title is preserved. Assignment ID, authorized metrics and exact scope assertions retained.'],applicationChanged:false},null,2));
