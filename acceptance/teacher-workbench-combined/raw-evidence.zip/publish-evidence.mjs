// Guarded, file-only packaging. No Git mutation, Docker work, commit or push.
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { createHash } from "node:crypto";
import { acquireLock, preflight, MIN_RUNTIME_GIB } from "./safety.mjs";
const root="C:/Users/sb128/.codex/visualizations/2026/10/25/01a174be-f6b2-7012-b723-c460b8858df5";
const state=join(root,"runtime");
if(process.argv[2]!=="--publish"){
  console.log("Prepared only. Run publish-evidence.mjs --publish [--report <root-authored-report>] after runtime work is finished.");
  process.exit(0);
}
const guardHash=createHash("sha256").update(readFileSync(new URL("./safety.mjs",import.meta.url))).digest("hex");
assert.equal(guardHash,"af01b05dd317682a47b6ec64acc5083cae1430383d697dcb1ede53687722c485");
const manifest=JSON.parse(readFileSync(join(state,"manifest.json"),"utf8"));
const release=acquireLock({task:"publish teacher combined evidence",project:"lp-teacher-combined-01a174be",state,sourceSha:manifest.sourceSha});
try{
  const observation=preflight({source:manifest.source,state,minimumGiB:MIN_RUNTIME_GIB,dockerRequired:false});
  writeFileSync(join(root,"verification","publication-preflight.json"),`${JSON.stringify(observation,null,2)}\n`);
  assert(observation.pass,"Insufficient file-system headroom for evidence packaging");
  const result=spawnSync("python",[fileURLToPath(new URL("./package-evidence.py",import.meta.url)),...process.argv.slice(2)],{encoding:"utf8",windowsHide:true,timeout:180_000,maxBuffer:4*1024*1024});
  process.stdout.write(result.stdout??"");process.stderr.write(result.stderr??"");
  assert.equal(result.status,0,"Evidence packaging stopped; preserve staging and inspect the reported exclusion/link issue");
}finally{release();}
