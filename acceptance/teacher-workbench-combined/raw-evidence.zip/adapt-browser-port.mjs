import { readFileSync,writeFileSync,readdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { join,dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
const root=dirname(fileURLToPath(import.meta.url)),hash=b=>createHash('sha256').update(b).digest('hex');
const file=join(root,'BROWSER_BUNDLE_PROVENANCE.json'),p=JSON.parse(readFileSync(file,'utf8'));
const paths=['guarded-focused-browser.mjs','BROWSER_COMMANDS.txt','prepare-browser-bundles.mjs'];
for(const dir of ['journey-bundle','visual-bundle'])for(const name of readdirSync(join(root,dir)))if(/\.(mjs|json|txt)$/.test(name))paths.push(join(dir,name));
const changed=[];
for(const path of paths){if(path.endsWith('safety.mjs'))continue;const abs=join(root,path),before=readFileSync(abs),after=Buffer.from(before.toString('utf8').replaceAll('http://localhost:3417','http://localhost:3449').replaceAll('Number(origin.port), 3417','Number(origin.port), 3449').replaceAll('origin.port), 3417','origin.port), 3449'));if(!before.equals(after)){writeFileSync(abs,after);changed.push({path,previousSha256:hash(before),currentSha256:hash(after)});}}
p.runtimeRevisions??=[];p.runtimeRevisions.push({at:new Date().toISOString(),reason:'Coordinator verified port3417 belongs to unrelated PID101696; new free loopback port3449 selected before any bundle execution',oldOrigin:p.origin,newOrigin:'http://localhost:3449',files:changed});p.origin='http://localhost:3449';writeFileSync(file,JSON.stringify(p,null,2)+'\n');console.log(JSON.stringify({adapted:changed.length,origin:p.origin,runtimeExecuted:false}));
