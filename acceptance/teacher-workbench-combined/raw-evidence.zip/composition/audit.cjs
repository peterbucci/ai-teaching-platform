const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const crypto = require('node:crypto');
const sourceRepo = process.argv[2] || 'C:/Users/sb128/Desktop/LearningPlatform';
const output = __dirname;
const baseline = '07efb7f821339538800f150f57b298eb2e606be3';
const candidate = 'c26664e49b7cc15fa7c63828f5c582c9b8cac2d8';
const expectedTree = '333b73e1cae1daddf6edd61300655d0b4825ed67';
const sources = [
  { owner: 'K Navigation', pr: 139, head: 'e88e45acea1478d562a2fb3fd2ebb9caa5403ed8', integration: '43ac64b2dd1efc5d57928aaec236c39d7fd39a50' },
  { owner: 'I Interventions', pr: 136, head: '83bba436ab148f9b2ddaa4de61d29b857458a138', integration: '9fdf0d1298fb55c793cb3a8d8233431488bfbbfb' },
  { owner: 'J Lessons', pr: 135, head: 'c56d31d594d9eedb30b0313c2ab3f22ce65e94a7', integration: '86c60347bdaddd88497c3cb49950d1eaf7dcbda2' },
  { owner: 'F Overview', pr: 138, head: '798f32438b1807d625e5c9b9ac9f0a5439dd5b41', integration: '08bf5d3e464ca3629bc7cabc07eeecea7998abf9' },
  { owner: 'H Concerns', pr: 137, head: 'afd91d6749129a77b88f020b2ac98201058cf082', integration: '744b5c71ce9432e57ca84c2b8b015fc83ca61f91' },
  { owner: 'G Roster', pr: 140, head: 'af4eec9c1df2e20658400881e94ff9dbbc7f012e', integration: 'edecbfd95b203568d7ac8957a002e5bba25b211b' },
  { owner: 'R03 student concept labels', pr: 134, head: '9b4f5e357146338e6d0b99dadc1a0104714ba406', integration: candidate, method: 'cherry-pick -x' },
];
function run(args, {input, env, allowConflict = false} = {}) {
  const result = spawnSync('git', args, {cwd: sourceRepo, input, encoding: 'utf8', maxBuffer: 20 * 1024 * 1024, env: {...process.env, ...env}});
  if (result.status !== 0 && !(allowConflict && result.status === 1)) throw new Error(JSON.stringify({args, status:result.status, stderr:result.stderr}));
  return result;
}
function git(args, options) { return run(args, options).stdout.trim(); }
function lines(text) { return text ? text.split(/\r?\n/) : []; }
const trees = new Map();
function object(ref, file) {
  if (!trees.has(ref)) {
    trees.set(ref,new Map(lines(git(['ls-tree','-r','--full-tree',ref])).map(line => {
      const separator = line.indexOf('\t');
      return [line.slice(separator + 1), line.slice(0,separator).split(' ')[2]];
    })));
  }
  const blob = trees.get(ref).get(file);
  if (!blob) throw new Error(`Missing object ${ref}:${file}`);
  return blob;
}
function isAncestor(a, b) { return run(['merge-base', '--is-ancestor', a, b], {allowConflict:true}).status === 0; }
function changed(a, b) { return lines(git(['diff', '--name-only', a, b])); }
const candidateTree = git(['rev-parse', `${candidate}^{tree}`]);
const owners = new Map();
for (const source of sources) {
  source.baselineIsAncestor = isAncestor(baseline, source.head);
  source.headIsAncestorOfCandidate = isAncestor(source.head, candidate);
  source.files = changed(baseline, source.head);
  for (const file of source.files) owners.set(file, [...(owners.get(file) || []), source]);
}
const exceptions = new Set(['scripts/check-metrics.ts', 'scripts/check-lesson-uncertainty.ts']);
const fileMatrix = [...owners].sort(([a], [b]) => a.localeCompare(b)).map(([file, fileOwners]) => {
  const candidateBlob = object(candidate, file);
  const sourceBlobs = fileOwners.map(source => ({owner:source.owner, head:source.head, blob:object(source.head, file)}));
  return {file, candidateBlob, sourceBlobs, intentionalResolution:exceptions.has(file), unchangedFromEverySource:sourceBlobs.every(s => s.blob === candidateBlob)};
});
console.log('Source and candidate tree manifests compared.');
const unexpectedOwnerDifferences = fileMatrix.filter(f => !f.unchangedFromEverySource && !f.intentionalResolution);
const candidateChanges = changed(baseline, candidate);
const unownedChanges = candidateChanges.filter(file => !owners.has(file));
const missingSourceChanges = [...owners.keys()].filter(file => !candidateChanges.includes(file));
const baselineFiles = lines(git(['ls-tree', '-r', '--name-only', baseline]));
const preservedFiles = baselineFiles.filter(file => !owners.has(file));
const recoveryFiles = baselineFiles.filter(file => /recovery/i.test(file));
const previousEvidenceFiles = baselineFiles.filter(file => /(^acceptance\/|\/verification\/|^tests\/artifacts\/)/.test(file));
const recoveryDifferences = recoveryFiles.filter(file => object(baseline,file) !== object(candidate,file));
const previousEvidenceDifferences = previousEvidenceFiles.filter(file => object(baseline,file) !== object(candidate,file));
const preservedScopes = ['lib/tutoring','lib/evaluation','lib/evidence','lib/lessons','app/teacher/evidence','app/api','db','content'];
const scopeDifferences = Object.fromEntries(preservedScopes.map(scope => [scope, lines(git(['diff','--name-only',baseline,candidate,'--',scope]))]));
const drawerFiles = ['app/teacher/workspace-panes.tsx','app/teacher/workspace-shell.css','tests/teacher-pane-drawer-browser.mjs'];
const drawerShared = drawerFiles.map(file => ({file,k:object('56e4915',file),i:object('9f30bee',file),candidate:object(candidate,file)}));
const r03SourcePatchId = git(['patch-id','--stable'], {input:git(['show','--pretty=format:',sources[6].head])}).split(' ')[0];
const r03CandidatePatchId = git(['patch-id','--stable'], {input:git(['show','--pretty=format:',candidate])}).split(' ')[0];
const resolutionDescriptions = {
  'scripts/check-lesson-uncertainty.ts': 'Union: retain resolved Overview sections, both uploaded assignments, distinct-student uncertainty/missing work and exact original-response actions; retain Insights heading plus enrolled-count alternatives, original uncertainty text and each exact evaluation/session anchor.',
  'scripts/check-metrics.ts': 'Union: retain Overview evidence discovery, G Roster/work-log exact attempt/card streamed-placeholder expansion, evaluation/source/return contracts and privacy checks; retain H rendered By idea navigation, exact evidence/session identities, provenance and refreshed displayed metrics. Remove obsolete direct session-link assumptions on the Roster landing and Concerns landing. Share evaluationId, escapedAnswer and concept declarations; preserve both result descriptions.',
};
const resolutions = [...exceptions].map(file => ({file,blob:object(candidate,file),sha256:crypto.createHash('sha256').update(git(['show',`${candidate}:${file}`])+'\n').digest('hex'),description:resolutionDescriptions[file]}));

// Recompose in an object-only repository. The shared application repository and
// every worktree remain unchanged. Only the two explicitly recorded resolution
// blobs are supplied; all other output is produced by Git's merge algorithm.
const bare = path.join(output,'recomposition.git');
if (!fs.existsSync(bare)) git(['init','--bare',bare]);
const commonGit = path.resolve(sourceRepo, git(['rev-parse','--git-common-dir']));
fs.writeFileSync(path.join(bare,'objects','info','alternates'), path.join(commonGit,'objects').replaceAll('\\','/')+'\n');
const indexFile = path.join(output,'recomposition.index');
const env = {GIT_INDEX_FILE:indexFile,GIT_AUTHOR_NAME:'Composition verification',GIT_AUTHOR_EMAIL:'verification@example.invalid',GIT_COMMITTER_NAME:'Composition verification',GIT_COMMITTER_EMAIL:'verification@example.invalid',GIT_AUTHOR_DATE:'2026-10-25T23:00:00Z',GIT_COMMITTER_DATE:'2026-10-25T23:00:00Z'};
const bareArgs = ['--git-dir',bare];
let current = baseline;
const recomposition = [];
for (const source of sources) {
  console.log(`Recomposing ${source.owner}.`);
  const result = run([...bareArgs,'merge-tree','--write-tree','--name-only',current,source.head], {env,allowConflict:true});
  const outputLines = lines(result.stdout.trim());
  let tree = outputLines[0];
  const step = {source:source.owner,head:source.head,input:current,mergeStatus:result.status,automaticTree:tree,mergeOutput:result.stdout.trim(),resolutions:[]};
  if (result.status === 1) {
    const conflicts = outputLines.slice(1,outputLines.indexOf('',1));
    if (conflicts.some(file => !exceptions.has(file))) throw new Error(`Unexpected recomposition conflicts: ${conflicts.join(', ')}`);
    git([...bareArgs,'read-tree',tree],{env});
    for (const file of conflicts) {
      const blob = object(candidate,file);
      git([...bareArgs,'update-index','--add','--cacheinfo',`100644,${blob},${file}`],{env});
      step.resolutions.push({file,blob});
    }
    tree = git([...bareArgs,'write-tree'],{env});
  }
  step.resolvedTree = tree;
  step.recordedIntegrationTree = git(['rev-parse',`${source.integration}^{tree}`]);
  step.matchesRecordedIntegrationTree = tree === step.recordedIntegrationTree;
  current = git([...bareArgs,'commit-tree',tree,'-p',current,'-p',source.head],{input:`Recompose ${source.owner}\n`,env});
  step.recompositionCommit = current;
  recomposition.push(step);
}
const recomposedTree = recomposition.at(-1).resolvedTree;
const productionFiles = fileMatrix.filter(f => /^(app|lib)\//.test(f.file) && !f.file.includes('/verification/') && !f.file.endsWith('.md') && !f.file.endsWith('.test.ts'));
const pass = candidateTree === expectedTree && sources.every(s => s.baselineIsAncestor) && sources.slice(0,6).every(s => s.headIsAncestorOfCandidate) && r03SourcePatchId === r03CandidatePatchId && unexpectedOwnerDifferences.length === 0 && unownedChanges.length === 0 && missingSourceChanges.length === 0 && recoveryDifferences.length === 0 && recomposedTree === candidateTree && recomposition.every(s => s.matchesRecordedIntegrationTree);
const report = {
  status:pass?'passed':'failed',baseline,candidate,candidateTree,expectedTree,
  sources,fileMatrix,productionFiles,unexpectedOwnerDifferences,unownedChanges,missingSourceChanges,
  counts:{candidateChangedFiles:candidateChanges.length,sourceUnionFiles:owners.size,productionOwnerFiles:productionFiles.length,baselineFilesPreservedOutsideSourceUnion:preservedFiles.length,baselineRecoveryFiles:recoveryFiles.length,previousEvidenceFiles:previousEvidenceFiles.length},
  recoveryDifferences,previousEvidenceDifferences,scopeDifferences,drawerShared,
  r03:{source:sources[6].head,candidateCommit:candidate,sourcePatchId:r03SourcePatchId,candidatePatchId:r03CandidatePatchId,equal:r03SourcePatchId===r03CandidatePatchId,sourceCommitAncestor:isAncestor(sources[6].head,candidate),note:'Exact cherry-pick -x patch; only four R03 files from the direct baseline child. No later #134 or N7 ancestry imported.'},
  resolutions,recomposition,recomposedTree,
  reviewLimit:'Composition verification was performed by the source-audit agent, which also authored the two conflict resolutions. Recomposition independently checks all source blobs and merge outputs but is not an independent acceptance or independent review of those two resolutions. It deliberately uses their recorded resolved blobs. Functional service/browser checks and final independent acceptance remain separate.',
  reproduction:'node audit.cjs C:/path/to/ai-teaching-platform (repository must contain the recorded source and candidate commits). Creates only this report directory and an object-only recomposition.git with source objects as read-only alternates. No worktree checkout, application edit, database workload or provider call.',
};
fs.writeFileSync(path.join(output,'composition.json'),JSON.stringify(report,null,2)+'\n');
fs.writeFileSync(path.join(output,'REPORT.txt'),[
  `Composition audit: ${report.status.toUpperCase()}`,
  `Baseline: ${baseline}`,`Candidate: ${candidate}`,`Tree: ${candidateTree}`,`Recomposed tree: ${recomposedTree}`,'',
  ...sources.map(s=>`${s.owner} #${s.pr}: ${s.head}; baseline ancestor=${s.baselineIsAncestor}; candidate ancestor=${s.headIsAncestorOfCandidate}; integration=${s.integration}`),'',
  `All ${productionFiles.length} changed production files match their owning source heads byte-for-byte.`,
  `${candidateChanges.length} changed files equal the complete source union; unowned changes=${unownedChanges.length}; missing source changes=${missingSourceChanges.length}.`,
  `${preservedFiles.length} pre-existing files outside source changes remain untouched. Recovery file differences=${recoveryDifferences.length}.`,
  `R03 patch IDs: ${r03SourcePatchId} / ${r03CandidatePatchId}.`,
  `Previous evidence differences: ${previousEvidenceDifferences.length}; listed in JSON for source-owned component harness changes (prior evidence blobs themselves remain present).`,
  '',...resolutions.map(r=>`${r.file}\nBlob: ${r.blob}\n${r.description}\n`),
  report.reviewLimit,'',report.reproduction,
].join('\n')+'\n');
console.log(JSON.stringify({status:report.status,candidate,candidateTree,recomposedTree,counts:report.counts,unexpectedOwnerDifferences,unownedChanges,missingSourceChanges,recoveryDifferences,previousEvidenceDifferences,scopeDifferences,r03:report.r03,report:path.join(output,'composition.json')},null,2));
process.exitCode = pass ? 0 : 1;
