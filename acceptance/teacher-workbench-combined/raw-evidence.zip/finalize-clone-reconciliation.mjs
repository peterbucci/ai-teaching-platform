// File-only finalization after root reviews the preserved, read-only diagnosis.
// Does not change DB rows, retry restore, restart containers or rewrite a failed receipt.
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { existsSync, readFileSync, readdirSync, rmdirSync, unlinkSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { LOCK_PATH } from "./safety.mjs";
const root="C:/Users/sb128/.codex/visualizations/2026/10/25/01a174be-f6b2-7012-b723-c460b8858df5";
const state=join(root,"runtime");
const failedDirectory=join(state,"clone-original-2026-10-25T20-41-48-928Z");
const failedPath=join(failedDirectory,"receipt.json");
const inspectionPath=join(failedDirectory,"auth-delta-inspection.json");
const ownerPath=join(LOCK_PATH,"owner.json");
const hash=(value)=>createHash("sha256").update(value).digest("hex");
const readJson=(path)=>JSON.parse(readFileSync(path,"utf8"));
if(process.argv.length!==3||process.argv[2]!=="--finalize-with-recorded-auth-delta") {
  console.log("Prepared only. Root must review auth-delta-inspection.json before explicitly passing --finalize-with-recorded-auth-delta.");
  process.exit(0);
}
assert.equal(hash(readFileSync(failedPath)),"ab1cba19ca3c3035a14a66d8adf8780652c90f8c690c332b2795e25a19ffa96b");
assert.equal(hash(readFileSync(inspectionPath)),"2ef3e92b4c7f97c0705473f2548ee6269dc6019e90ae7a7786dfa272b946b0a0");
assert.equal(hash(readFileSync(new URL("./safety.mjs",import.meta.url))),"af01b05dd317682a47b6ec64acc5083cae1430383d697dcb1ede53687722c485");
const failed=readJson(failedPath),inspection=readJson(inspectionPath),owner=readJson(ownerPath);
assert.equal(owner.task,"final teacher combined original fixture clone");
assert.equal(owner.project,"lp-teacher-combined-01a174be");
assert.equal(owner.sourceSha,"c26664e49b7cc15fa7c63828f5c582c9b8cac2d8");
assert.equal(owner.pid,69988);
assert.equal(owner.startedAt,"2026-10-25T20:41:48.929Z");
let alive=true;try{process.kill(owner.pid,0);}catch(error){if(error.code==="ESRCH")alive=false;else throw error;}
assert(!alive,"Original clone process still exists");
assert.deepEqual(readdirSync(LOCK_PATH),["owner.json"]);
assert.equal(inspection.status,"read-only diagnosis passed");
assert(inspection.originalSourceUnchanged&&inspection.targetDomainRowsUnchanged);
assert.deepEqual(inspection.sourceNow,failed.source.before);
assert.deepEqual(inspection.targetNow.filter((row)=>row.name!=="auth_session"),failed.source.before.filter((row)=>row.name!=="auth_session"));
assert.equal(inspection.addedAuthSessions.length,1);
assert.equal(inspection.addedAuthSessions[0].sessionId,"4IdAolDBgUOh2ywvAQmG4QqegUz6bLCQ");
assert.equal(inspection.addedAuthSessions[0].email,"acceptance-shell-teacher@example.invalid");
assert.equal(inspection.targetOriginalAuthRowsFingerprint,failed.source.before.find((row)=>row.name==="auth_session").fingerprint);
const marker=join(state,"original-fixture-clone-completed.json");
assert(!existsSync(marker),"Completion already recorded");
const receipt={
  status:"domain clone verified with recorded authentication-only delta",failedReceipt:failedPath,
  inspectionReceipt:inspectionPath,sourceSha:failed.source.applicationSha,targetSha:failed.target.applicationSha,
  dumpSha256:failed.source.dumpSha256,originalSourceUnchanged:true,
  originalPublicTables:32,unchangedNonSessionTables:31,allOriginalAuthSessionRowsPreserved:true,
  addedAuthSession:inspection.addedAuthSessions[0],
  limitation:"One new fictional teacher authentication session was created after app restart. The responsible request is not attributed. The row is retained; this does not establish visual or independent application acceptance.",
  followupAction:"Original failed clone and diagnosis retained; no clone or restore repeated, no database row removed, no Docker mutation during finalization",
  completedAt:new Date().toISOString(),ownerLockTokenSha256:hash(owner.token),lockReleased:false,
};
writeFileSync(marker,`${JSON.stringify(receipt,null,2)}\n`,{flag:"wx"});
assert.equal(readJson(ownerPath).token,owner.token,"Lock ownership changed before release");
unlinkSync(ownerPath);rmdirSync(LOCK_PATH);
receipt.lockReleased=true;
writeFileSync(marker,`${JSON.stringify(receipt,null,2)}\n`);
writeFileSync(join(failedDirectory,"reconciliation-finalized.json"),`${JSON.stringify(receipt,null,2)}\n`,{flag:"wx"});
console.log(JSON.stringify({status:receipt.status,lockReleased:true,marker,failedReceiptPreserved:true,extraAuthRowRetained:true}));
