# G — integrated Roster and selected-student visual comparison

**Result: core workspace structures are present, with unresolved P2 density and summary-parity differences. This is a delegated visual comparison, not independent final acceptance.**

Compared the actual approved Workbench v2.2 export with the pinned integrated application on October 25, 2026. Inspected all twenty images: two states × five display conditions × prototype/application. Read the associated reports and G's source acceptance caveats. No browser, database, login or provider operations were performed by this reviewer.

## Evidence identity and limits

- Application commit: `c26664e49b7cc15fa7c63828f5c582c9b8cac2d8`; tree: `333b73e1cae1daddf6edd61300655d0b4825ed67`.
- Application evidence: [application-01/report.json](application-01/report.json), completed `2026-10-25T21:00:41.913Z`.
- Prototype: actual `Main.dc.html` export; HTML SHA-256 `c853369da1250adf24a741a38c3d94d3c97a976c012c352732cf4dd8d924cb54`; original archive SHA-256 `74bc909dffba839d6850823b35b8c8fc3c67adf1a64b14d67f245560fb87768f`. Provenance: [prototype-01/report.json](prototype-01/report.json).
- Native 200% comparisons use the full `*-native200-cdp.png` visible surfaces, 1416 × 908 physical pixels. Both reports record 708 × 454 CSS pixels, DPR 2, CSS zoom 1 and visual-viewport scale 1. The smaller ordinary native screenshots were not used to judge layout.
- The application fixture is **27 enrolled students, one Evaporation concept**, with the selected fictional student having **two sessions and three submitted responses**. The prototype is 18 students/five networking concepts, and its selected Lena Fischer has two sessions/five answers. The three application responses are not three enrolled students. Empty rows and fewer concept columns are fixture differences, not missing-grid defects.
- The reports show all ten G captures completed without reported page errors or document overflow. Their selected-student pane probes pass for Ideas, Work log and Summary at all five conditions: adjacent at desktop, Summary drawer at tablet, tabs on phones/native zoom. These are recorded harness results; this reviewer did not independently operate those controls.

## Comparison across all five display conditions

Coordinates below are approximate visual positions in the inspected viewport images, not a new geometry measurement.

| Display | Roster comparison | Selected-student comparison |
| --- | --- | --- |
| 1440 × 1000 | Both show a real student-by-concept grid, legend, student links and intervention column. Application table begins around y553 versus prototype y424. Application adds assignment/source/participation filters and Apply; prototype has name search only. App's one concept and many empty rows are fixture-dependent. [Application](application-01/roster-1440x1000.png) · [Prototype](prototype-01/roster-1440x1000.png) | Ideas / Work log / Summary all appear side by side. App first original-answer text begins around y750 versus prototype y460; app shows one full response card where prototype shows multiple responses and help events. The Summary contains a real delivered intervention and recorded-activity counts, but differs from the prototype's correctness-by-situation section. [Application](application-01/roster-student-1440x1000.png) · [Prototype](prototype-01/roster-student-1440x1000.png) |
| 1024 × 768 | Grid is present and contained. App table begins around y580 versus prototype y424; fewer rows are visible because filters/header consume more space, independent of the differing row content. [Application](application-01/roster-1024x768.png) · [Prototype](prototype-01/roster-1024x768.png) | Both use Ideas + Work log with a Summary opener. App's first question reaches the bottom edge and original answer is below the first viewport; prototype shows two original answers and begins a help event. No visual evidence that the pane was removed; this is a content-density mismatch. [Application](application-01/roster-student-1024x768.png) · [Prototype](prototype-01/roster-student-1024x768.png) |
| 390 × 844 | Both have contained horizontal grid scrolling and bottom assignment navigation. App table begins around y628 versus prototype y350: one substantial row versus about five prototype rows is visible. The extra Back-to-Assignments row, page spacing and expanded filters contribute before any fixture data. [Application](application-01/roster-390x844.png) · [Prototype](prototype-01/roster-390x844.png) | Both expose Ideas / Work log / Summary tabs. App retains a separate student heading, counts, scope disclosure and duplicate Work log pane heading above the session; only the beginning of its first answer is visible above bottom navigation. Prototype shows two answers and the start of a help event. [Application](application-01/roster-student-390x844.png) · [Prototype](prototype-01/roster-student-390x844.png) |
| 320 × 844 | No document overflow is recorded. App's concept column is partly outside the horizontal grid viewport, as expected for a scrollable table; prototype also requires horizontal scrolling to reach concepts. App table starts around y668 versus prototype y398 and only part of the first row is visible. [Application](application-01/roster-320x844.png) · [Prototype](prototype-01/roster-320x844.png) | Tabs remain readable and selected Work log is clear. App first answer begins at the bottom edge; prototype shows a full first answer, its Read in full action and the start of the next question. [Application](application-01/roster-student-320x844.png) · [Prototype](prototype-01/roster-student-320x844.png) |
| Native browser 200% | Full app surface shows header, page title and filters; legend/grid are below the first visible surface. Prototype shows legend and table header. Both retain bottom navigation without reported document overflow. [Application full surface](application-01/roster-native200-cdp.png) · [Prototype full surface](prototype-01/roster-native200-cdp.png) | App full surface reaches only the Work log / Every saved session heading; no session or original answer is initially visible. Prototype reaches the first original answer. All three tab labels remain visible in both. [Application full surface](application-01/roster-student-native200-cdp.png) · [Prototype full surface](prototype-01/roster-student-native200-cdp.png) |

## Ranked remaining findings

### P2 — G-V1: excess framing materially reduces the visible investigation area

Across desktop, tablet, phones and native 200%, repeated navigation/context, large vertical gaps, expanded filter controls and repeated Work log headings push the actual work substantially lower than in the approved prototype. This is clearest at 1024 and native 200%, where the prototype exposes original work but the application initially exposes mostly framing; at 390 the original answer only begins near the fixed bottom navigation. The offset exists before response length or the number of concepts/students can account for it.

This is an unresolved visual fidelity/usability issue, **not evidence of lost responses or inaccessible panes**. The captured text and recorded pane probes contain the full work log, and scrolling is expected. A later focused correction should preserve the authorization/scope disclosures while reducing duplicated framing. No correction was made during this integration review.

### P2 — G-V2: Summary does not reproduce the prototype's supported-answer comparison structure

At 1440 the prototype Summary visibly includes **Answers fully correct, by situation**, separating first answers without help, answers after help/reading, immediate checks, teacher review checks and later reviews with denominators. The integrated Summary instead shows **Recorded activity** counts: submitted responses, responses with help, immediate retests, delayed reviews, displayed help and evaluations not accepted. Its delivered-intervention relationship is present and meaningful, but the comparison structure is different.

This is a genuine representation/capability difference, not merely one concept versus five or three responses versus five. G's source report deliberately replaces informal performance summaries with supported recorded counts. That conservative evidence choice should remain explicit; the integration must not claim full visual parity or invent missing comparisons. Independent acceptance should decide whether this bounded deviation is acceptable for the candidate.

### P3 — G-V3: response symbols and typography retain a different visual language

The prototype uses compact circular/diamond response marks and generally larger table labels; the application uses bordered square symbols, a compact 12px table and 11px table headings (`roster.css`), while dedicating more space to surrounding controls. Status meaning remains available in the visible legend, and the work-log concept names remain human-readable. This is a lower-priority visual difference, not a demonstrated evidence-integrity or contrast failure.

## Preserved structures and source caveats

The former missing-structure finding is materially addressed: a student-by-concept grid exists; selecting a student produces Ideas, a cross-session assessed-response log and Summary; exact-session actions remain visible in the content; intervention delivery/follow-up relationships are displayed from records. The screenshots and harness receipts support those narrower claims.

G's source report at `af4eec9:app/teacher/students/verification/ACCEPTANCE.md` remains relevant: the log includes assessed responses and recorded assistance for the selected assignment/source, **not every dialogue message**; intervention history is bounded to the latest 30 drafts; absent help or causal links are not inferred. The actual prototype's promise of the same complete timeline the student sees is therefore not fully established by these captures. This known coverage limit needs to remain in the final handoff; it must not be hidden as a fixture difference.

No P0/P1 failure is demonstrated in these G images. No statement here establishes final independent acceptance, full conversation completeness, physical-touch behavior or screen-reader usability. Composition and service/browser results remain separate evidence.
