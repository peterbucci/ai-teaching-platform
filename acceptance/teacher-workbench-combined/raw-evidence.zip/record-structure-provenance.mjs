import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=dirname(fileURLToPath(import.meta.url)),files=['journey-bundle/combined-structure-handoffs.mjs','journey-bundle/read-only-runtime.mjs','journey-bundle/safety.mjs','STRUCTURE_HANDOFF_COMMANDS.txt'];
const provenance={status:'prepared-not-executed',at:new Date().toISOString(),applicationSha:'c26664e49b7cc15fa7c63828f5c582c9b8cac2d8',applicationTree:'333b73e1cae1daddf6edd61300655d0b4825ed67',project:'lp-teacher-combined-01a174be',origin:'http://localhost:3449',sourceAudit:'Read exact combined source, no owner fixture runner or receiver-mode behavior imported',method:'Four bounded readonly browser handoffs with one fictional login, actual links and snapshots; no database changes, model calls, browser execution or shared lock acquisition during preparation',files:files.map(path=>({path,sha256:createHash('sha256').update(readFileSync(join(root,path))).digest('hex')}))};
writeFileSync(join(root,'STRUCTURE_HANDOFF_PROVENANCE.json'),JSON.stringify(provenance,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({status:provenance.status,helperSha256:provenance.files[0].sha256}));
