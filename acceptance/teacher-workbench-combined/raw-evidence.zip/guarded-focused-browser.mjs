/** Pinned, serialized runner for existing page-owner browser regressions. No stack setup. */
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFileSync,writeFileSync,existsSync } from 'node:fs';
import { resolve,join,dirname,relative,isAbsolute } from 'node:path';
import { pathToFileURL,fileURLToPath } from 'node:url';
const [kind,stateArg,outArg,arg] = process.argv.slice(2);
const files={returns:'tests/teacher-contextual-return-browser.mjs',evidence:'tests/teacher-evidence-return-regression-browser.mjs',navigation:'tests/teacher-return-regression-browser.mjs',hydration:'tests/intervention-hydration-browser.mjs'};
assert.ok(Object.hasOwn(files,kind),'Choose returns, evidence, navigation, or hydration');
assert.ok(stateArg&&outArg); const state=resolve(stateArg),out=resolve(outArg);
assert.equal(existsSync(out),false,'Use fresh evidence directory');
assert.ok(existsSync(dirname(out)),'Evidence parent must exist');
const manifest=JSON.parse(readFileSync(join(state,'manifest.json'),'utf8'));
assert.equal(manifest.sourceSha,'c26664e49b7cc15fa7c63828f5c582c9b8cac2d8');
assert.equal(manifest.sourceTree,'333b73e1cae1daddf6edd61300655d0b4825ed67');
assert.equal(manifest.project,'lp-teacher-combined-01a174be');
assert.equal(manifest.origin,'http://localhost:3449');
assert.equal(manifest.paidModelCallsAuthorized,false);
assert.match(manifest.configurationCategory,/provider-disabled/);
const rel=relative(manifest.source,out);assert.ok(rel.startsWith('..')||isAbsolute(rel));
const envPath=join(state,'.env.acceptance'),env=readFileSync(envPath,'utf8');
for(const key of ['OPENAI_API_KEY','OPENAI_MODEL'])assert.deepEqual(env.split(/\r?\n/).filter(line=>line.startsWith(key+'=')),[key+'=']);
for(const [ref,expected] of [['HEAD',manifest.sourceSha],['HEAD^{tree}',manifest.sourceTree]]){const r=spawnSync('git',['-C',manifest.source,'rev-parse',ref],{encoding:'utf8',windowsHide:true});assert.equal(r.status,0);assert.equal(r.stdout.trim(),expected);}
const hash=b=>createHash('sha256').update(b).digest('hex');
const safety=join(dirname(fileURLToPath(import.meta.url)),'journey-bundle/safety.mjs');
assert.equal(hash(readFileSync(safety)),'af01b05dd317682a47b6ec64acc5083cae1430383d697dcb1ede53687722c485');
const {acquireLock,preflight,MIN_RUNTIME_GIB,LOCK_PATH}=await import(pathToFileURL(safety).href);
const script=join(manifest.source,files[kind]);assert.ok(existsSync(script));
const args=['--experimental-strip-types','--conditions=react-server',script,manifest.origin];
if(kind==='hydration'){assert.match(arg??'',/^[a-f0-9-]{36}$/);args.push(arg,out);}
else {args.push(out);if(kind==='returns')args.push('integrated');}
const receipt={kind,sourceSha:manifest.sourceSha,sourceTree:manifest.sourceTree,project:manifest.project,origin:manifest.origin,script:files[kind],scriptSha256:hash(readFileSync(script)),wrapperSha256:hash(readFileSync(new URL(import.meta.url))),startedAt:new Date().toISOString(),paidModelCalls:0,status:'running'};
const receiptFile=out+'.guard.json';assert.equal(existsSync(receiptFile),false);
const save=()=>writeFileSync(receiptFile,JSON.stringify(receipt,null,2)+'\n');
const release=acquireLock({action:'combined-focused-browser-'+kind,state,out,source:manifest.source,sourceSha:manifest.sourceSha});let uncertain=false;
try{
 receipt.lockOwner=JSON.parse(readFileSync(join(LOCK_PATH,'owner.json'),'utf8'));
 receipt.preflight=preflight({source:manifest.source,state,minimumGiB:MIN_RUNTIME_GIB,explicitPath:manifest.dockerDataPath,probeContainer:manifest.storageProbeContainer});save();assert.equal(receipt.preflight.pass,true);
 const result=spawnSync(process.execPath,args,{cwd:manifest.source,encoding:'utf8',timeout:600000,windowsHide:true,env:{...process.env,OPENAI_API_KEY:'',OPENAI_MODEL:'',K_SOURCE_SHA:manifest.sourceSha,INTERVENTION_TEST_ENV:envPath}});
 uncertain=Boolean(result.error);receipt.exitCode=result.status;receipt.error=result.error?.message??null;
 writeFileSync(out+'.stdout.log',result.stdout??'',{flag:'wx'});writeFileSync(out+'.stderr.log',result.stderr??'',{flag:'wx'});
 receipt.status=uncertain?'uncertain':result.status===0?'process-completed-inspect-case-report':'failed';
 if(uncertain){receipt.lockRetained=true;receipt.reconciliationRequired='Child/browser may still exist. Reconcile owned process/outcome before coordinator releases this exact lock. No automatic retry.';}
 if(result.status!==0)process.exitCode=1;
}catch(error){receipt.status='failed';receipt.error=String(error);process.exitCode=1;}
finally{receipt.finishedAt=new Date().toISOString();if(!uncertain)release();save();console.log(JSON.stringify({status:receipt.status,receipt:receiptFile,caseReport:join(out,'report.json')}));}
