/** Usage: node capture-application-v3.mjs <runtime-final> <fresh-out> <safety.mjs> <scenario.json> */
import assert from "node:assert/strict";
import { join } from "node:path";
import { setup,loadJson,hashFile,VIEWPORTS,REQUIRED_STATES,browserExecutable,nativeContext,measureZoom,verifyZoom,capture } from "./capture-common.mjs";
const [stateArg,outArg,safetyArg,scenarioArg]=process.argv.slice(2);
assert.ok(scenarioArg,"Explicit fixture/state scenario required; missing authoring IDs must remain unrun.");
const scenario=loadJson(scenarioArg);
assert.equal(typeof scenario.fixtureLabel,"string"); assert.ok(Array.isArray(scenario.states));
const seen=new Set();
for(const item of scenario.states) {
  assert.ok(REQUIRED_STATES.includes(item.name)||item.name==="roster-student");assert.ok(!seen.has(item.name));seen.add(item.name);
  assert.ok(item.path===null||(/^\/teacher(?:\/|\?|$)/.test(item.path)&&!/[<>\s]|REQUIRED/.test(item.path)));
  assert.equal(typeof item.fixtureLabel,"string");
  if (item.readySelector) assert.equal(typeof item.readySelector,"string");
  for (const pane of item.paneProbes ?? []) {assert.equal(typeof pane.label,"string");assert.equal(typeof pane.selector,"string");}
  for(const action of item.actions??[]) assert.ok(["button","tab","summary"].includes(action.role)&&typeof action.name==="string");
}
const h=await setup(stateArg,outArg,safetyArg,import.meta.url),{report}=h;
report.category="actual combined application; GET-only after authorized fictional teacher login";
report.fixtureLabel=scenario.fixtureLabel;report.scenarioSha256=hashFile(scenarioArg);
report.requiredStates=scenario.captureScope ?? REQUIRED_STATES;
report.requestedStates=[...report.requiredStates];
assert.deepEqual([...seen].sort(), [...report.requiredStates].sort(), "Capture scenario must contain exactly the declared comparison scope");
report.missingStates=report.requiredStates.filter(name=>!seen.has(name));
report.excludedHistoricalStates=REQUIRED_STATES.filter(name=>!seen.has(name));
report.scopeReason=scenario.scopeReason ?? "Original complete comparison matrix";
const contexts=[];let browser;
async function readyShell(page, expectedText = null) {
  // Synchronous predicate: this Playwright runtime does not await an async
  // predicate before deciding whether waitForFunction's polling has succeeded.
  const inspect = expected => {
    const visible = element => {
      const box = element.getBoundingClientRect();
      const style = getComputedStyle(element);
      return element.isConnected && box.width > 0 && box.height > 0 &&
        style.visibility !== "hidden" && style.display !== "none";
    };
    const all = [...document.querySelectorAll(".tw-shell[data-scope]")];
    const shells = all.filter(visible);
    if (shells.length !== 1) return false;
    const shell = shells[0];
    const mains = [...shell.querySelectorAll("main")].filter(visible);
    if (mains.length !== 1 || mains[0].getAttribute("aria-busy") === "true") return false;
    const main = mains[0];
    const headings = [...main.querySelectorAll("h1,h2")].filter(visible)
      .map(element => element.innerText.trim()).filter(Boolean);
    if (!headings.length || (expected && !main.innerText.includes(expected))) return false;
    const switcher = shell.querySelector(".tw-scope-switch");
    if (!switcher) return false;
    const propsKey = Object.keys(switcher).find(key => key.startsWith("__reactProps$"));
    if (!propsKey || typeof switcher[propsKey]?.onClick !== "function") return false;
    const box = shell.getBoundingClientRect();
    return { scope:shell.dataset.scope, headings,
      totalScopedShells:all.length, visibleScopedShells:shells.length,
      expectedText:expected, expectedTextVisible:expected ? true : null,
      shellControlHydrated:true,
      geometry:[box.x,box.y,box.width,box.height],
      textLength:main.innerText.length };
  };
  async function observed() {
    const handle = await page.waitForFunction(inspect,expectedText,{timeout:20000,polling:"raf"});
    try {
      const value = await handle.jsonValue();
      assert.ok(value && typeof value === "object","Readiness must return an observed object, never false");
      assert.equal(value.visibleScopedShells,1);
      assert.equal(value.shellControlHydrated,true);
      if (expectedText) assert.equal(value.expectedTextVisible,true);
      return value;
    } finally { await handle.dispose(); }
  }
  const fingerprint = item => JSON.stringify([item.scope,item.headings,item.geometry,item.textLength]);
  for (let stabilityAttempt=1; stabilityAttempt<=3; stabilityAttempt++) {
    const before = await observed();
    // Async work belongs in evaluate, not the polling predicate.
    await page.evaluate(() => new Promise(resolve => {
      let frames=0;
      const tick=() => ++frames===3 ? resolve() : requestAnimationFrame(tick);
      requestAnimationFrame(tick);
    }));
    const after = await observed();
    if (fingerprint(before)===fingerprint(after))
      return {...after,stableAnimationFrames:3,stabilityAttempt};
  }
  throw new Error("Visible hydrated shell did not stabilize across the bounded readiness observations");
}
async function login(context) {
  let allowed=true;
  await context.route("**/*",async route=>{
    const request=route.request(),u=new URL(request.url());
    if(["data:","blob:"].includes(u.protocol))return route.continue();
    if(u.origin===h.manifest.origin&&["GET","HEAD","OPTIONS"].includes(request.method()))return route.continue();
    if(allowed&&u.origin===h.manifest.origin&&u.pathname==="/api/auth/demo-sign-in"&&request.method()==="POST") {report.allowedLoginRequests.push({url:u.href,method:request.method()});return route.continue();}
    report.blockedRequests.push({url:u.href,method:request.method()});return route.abort("blockedbyclient");
  });
  const page=context.pages()[0]??await context.newPage();page.setDefaultTimeout(20000);
  await page.goto(h.manifest.origin+"/login");
  await page.getByRole("button",{name:"Demo teacher",exact:true}).click();
  await page.waitForURL("**/teacher");await readyShell(page);allowed=false;
  return page;
}
async function probeLessons(page,result) {
  result.lessonChecks=[];
  async function probe(name,fn){const check={name,status:"unrun"};try{Object.assign(check,await fn());check.status="passed";}catch(error){check.status="failed";check.error=error.message;}result.lessonChecks.push(check);}
  await probe("Details keyboard disclosure and focus",async()=>{
    const details=page.locator(".ll-details").first(),summary=details.locator("summary");
    await summary.focus();await page.keyboard.press("Enter");
    assert.equal(await details.getAttribute("open"),"");
    await details.locator("dl").waitFor({state:"visible"});
    const metadata=await details.locator("dl").innerText();
    assert.ok(metadata.includes("Source")&&metadata.includes("Draft")&&metadata.includes("Publication history"));
    const focus=await summary.evaluate(e=>({isActive:document.activeElement===e,focusVisible:e.matches(":focus-visible"),outline:getComputedStyle(e).outline,boxShadow:getComputedStyle(e).boxShadow}));
    assert.equal(focus.isActive,true);assert.equal(focus.focusVisible,true);
    await page.keyboard.press("Enter");assert.equal(await details.getAttribute("open"),null);
    return {metadata,focus,closedAgain:true};
  });
  await probe("Search, keyboard tab and clear",async()=>{
    const term=(await page.locator(".la-lesson-name").first().innerText()).trim();assert.ok(term);
    const input=page.getByRole("textbox",{name:"Find a lesson",exact:true});
    await input.fill(term);await input.focus();await page.keyboard.press("Tab");
    const button=page.getByRole("button",{name:"Search",exact:true});
    const focus=await button.evaluate(e=>({isActive:document.activeElement===e,focusVisible:e.matches(":focus-visible"),outline:getComputedStyle(e).outline,boxShadow:getComputedStyle(e).boxShadow}));
    assert.equal(focus.isActive,true);assert.equal(focus.focusVisible,true);
    await page.keyboard.press("Enter");await page.waitForURL(u=>u.pathname==="/teacher/lessons"&&u.searchParams.get("q")===term);
    await page.locator(".ll-list").waitFor({state:"visible"});
    const titles=await page.locator(".la-lesson-name").allTextContents();assert.ok(titles.length>0&&titles.every(t=>t.toLowerCase().includes(term.toLowerCase())));
    const filteredUrl=page.url();await page.getByRole("link",{name:"Clear",exact:true}).click();
    await page.waitForURL(u=>u.pathname==="/teacher/lessons"&&!u.searchParams.has("q"));
    await page.locator(".ll-list").waitFor({state:"visible"});
    return {term,focus,filteredUrl,titles,clearUrl:page.url()};
  });
}
async function runStates(page,size,native200=false) {
  for(const item of scenario.states) {
    h.guard(size+":"+item.name);
    const result={name:item.name,path:item.path,fixtureLabel:item.fixtureLabel,viewportLabel:size,native200,status:"unrun",errors:[]};
    if(!item.path) {result.reason=item.unrunReason??"No exact authorized fixture URL supplied";report.states.push(result);await h.save();continue;}
    const errors=e=>result.errors.push(e.message);page.on("pageerror",errors);
    try {
      const response=await page.goto(h.manifest.origin+item.path,{waitUntil:"domcontentloaded"});
      result.httpStatus=response?.status();assert.ok(response?.ok());
      assert.equal(new URL(page.url()).pathname,new URL(h.manifest.origin+item.path).pathname,"Unexpected redirect");
      if (item.readySelector) await page.locator(item.readySelector).filter({visible:true}).waitFor({state:"visible",timeout:20000});
      result.readiness = await readyShell(page,item.expectedText ?? null);
      const shell=page.locator(".tw-shell[data-scope]").filter({visible:true});
      assert.equal(await shell.count(),1,"Expected one visible hydrated application shell");
      for(const action of item.actions??[]) {
        const locator=(action.role==="summary"?shell.locator("summary").filter({hasText:action.name}):shell.getByRole(action.role,{name:action.name,exact:true})).filter({visible:true});
        await locator.waitFor();assert.equal(await locator.count(),1,"Action must identify one visible control");await locator.click();
      }
      await page.waitForTimeout(300);
      result.finalUrl=page.url();Object.assign(result,await capture(page,h.out,item.name+"-"+size,native200));result.status="captured";
      // Primary image precedes read-only pane probes: the shown state remains
      // directly comparable with the selected prototype state.
      result.structureChecks=[];
      for (const structure of item.structureProbes ?? []) {
        const count=await page.locator(structure.selector).count();
        result.structureChecks.push({label:structure.label,selector:structure.selector,count,status:count>0?"passed":"failed"});
      }
      result.paneChecks=[];
      for (const pane of item.paneProbes ?? []) {
        const check={label:pane.label,selector:pane.selector,status:"unrun"};
        try {
          const modal=page.locator("dialog:modal");if(await modal.count())await page.keyboard.press("Escape");
          const tab=page.getByRole("tab",{name:pane.label,exact:true}).filter({visible:true});
          const opener=page.getByRole("button",{name:"Open "+pane.label,exact:true}).filter({visible:true});
          if(await tab.count()){assert.equal(await tab.count(),1);await tab.click();check.interaction="selected visible pane tab";}
          else if(await opener.count()){assert.equal(await opener.count(),1);await opener.click();check.interaction="opened visible contextual drawer";}
          else check.interaction="already adjacent in this layout";
          await page.locator(pane.selector).filter({visible:true}).waitFor({state:"visible",timeout:10000});
          check.status="passed";check.url=page.url();
          check.visibleText=(await page.locator(pane.selector).filter({visible:true}).innerText()).slice(0,1800);
        }catch(error){check.status="failed";check.error=error.message;}
        result.paneChecks.push(check);
      }
      if(item.mobileLessonProbes&&(native200||["390x844","320x844"].includes(size)))await probeLessons(page,result);
    }catch(error){result.status="failed";result.error=error.message;await page.screenshot({path:join(h.out,item.name+"-"+size+"-failed.png")}).catch(()=>{});}
    finally{page.off("pageerror",errors);report.states.push(result);await h.save();console.log(size+" "+item.name+": "+result.status);}
  }
}
try {
  browser=await h.chromium.launch({headless:true,executablePath:browserExecutable()});
  const regular=await browser.newContext({viewport:VIEWPORTS[0],deviceScaleFactor:1});contexts.push(regular);
  const page=await login(regular);
  for(const viewport of VIEWPORTS){await page.setViewportSize(viewport);await runStates(page,viewport.width+"x"+viewport.height);}
  await regular.close();await browser.close();browser=null;
  const nonce=Date.now();h.guard("native100");
  const native100=await nativeContext(h.chromium,h.state,"app-"+nonce+"-100",1);contexts.push(native100);
  const base=await login(native100);report.native100=await measureZoom(base);await native100.close();
  h.guard("native200");const native200=await nativeContext(h.chromium,h.state,"app-"+nonce+"-200",2);contexts.push(native200);
  const zoom=await login(native200);report.native200=await measureZoom(zoom);report.native200Verified=verifyZoom(report.native100,report.native200);
  if(report.native200Verified)await runStates(zoom,"native200",true);else report.native200Failure="Browser zoom measurement did not establish 200%; no native200 state is accepted.";
}catch(error){report.fatal=error.message;process.exitCode=1;}
finally {for(const context of contexts)await context.close().catch(()=>{});if(browser)await browser.close().catch(()=>{});report.finishedAt=new Date().toISOString();report.summary={captured:report.states.filter(s=>s.status==="captured").length,failed:report.states.filter(s=>s.status==="failed").length,unrun:report.states.filter(s=>s.status==="unrun").length,functionalProbeFailures:report.states.flatMap(s=>[...(s.paneChecks??[]),...(s.structureChecks??[]),...(s.lessonChecks??[])]).filter(c=>c.status==="failed").length,missingStates:report.missingStates};await h.save();h.release();}




