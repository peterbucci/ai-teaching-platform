import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,copyFileSync,constants} from 'node:fs';
import {createHash} from 'node:crypto';
import {dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=dirname(fileURLToPath(import.meta.url)),bundle=join(root,'journey-bundle'),hash=b=>createHash('sha256').update(b).digest('hex');
const originalPath=join(bundle,'intervention-continuation-browser.mjs'),original=readFileSync(originalPath),failedPath=join(root,'new-intervention-browser-01/report.json'),failedBytes=readFileSync(failedPath),failed=JSON.parse(failedBytes),failedHash=hash(failedBytes);
assert.equal(failedHash,'759043e3379d46967a459a27314a907e32cb8be600f220411cbfab81721355c7');assert.equal(failed.failure_stage,'same-student-opens-assigned-review');assert.equal(failed.lock_retained,false);
assert.deepEqual(failed.mutations.map(m=>[m.action,m.http_status,m.status]),['save','approve','deliver'].map(a=>[a,200,'acknowledged']));
copyFileSync(originalPath,join(bundle,'intervention-continuation-browser-v1-delivered-title-collision.mjs'),constants.COPYFILE_EXCL);
let src=original.toString();
src=src.replace('[\n    "review-and-submit",\n    "inspect-followup",\n  ].includes(phase)','["resume-delivered"].includes(phase)');
const start=src.indexOf('const directAuthoring ='),end=src.indexOf('const environment =');assert.ok(start>0&&end>start);
src=src.slice(0,start)+`const directAuthoring=false;
const preparation=seam.preparation,authoring=preparation.authoring;
assert.equal(hash(seamBytes),"${failedHash}","Resume only the exact acknowledged-delivery/title-collision receipt");
assert.equal(seam.phase,"review-and-submit");assert.equal(seam.status,"failed");
assert.equal(seam.failure_stage,"same-student-opens-assigned-review");assert.match(seam.error,/strict mode violation/);
assert.equal(seam.lock_retained,false);
assert.deepEqual(seam.mutations.map(m=>[m.action,m.http_status,m.status]),["save","approve","deliver"].map(a=>[a,200,"acknowledged"]));
assert.equal(seam.approval_id,"f187e046-fa5b-4f9d-bb3e-ddd1b457cee6");assert.equal(seam.delivery_id,"91e360b9-7385-4453-a571-6aaf71e6840b");
assert.equal(preparation.draft_id,"7dd12f61-4dbd-46d4-8a57-8381d8a7bb87");assert.equal(preparation.status,"completed");
assert.equal(manifest.sourceSha,"c26664e49b7cc15fa7c63828f5c582c9b8cac2d8");assert.equal(manifest.sourceTree,"333b73e1cae1daddf6edd61300655d0b4825ed67");
assert.equal(manifest.project,"lp-teacher-combined-01a174be");assert.equal(manifest.origin,"http://localhost:3449");assert.equal(manifest.paidModelCallsAuthorized,false);
assert.equal(seam.source_sha,manifest.sourceSha);assert.equal(seam.source_tree,manifest.sourceTree);assert.equal(seam.project,manifest.project);assert.equal(seam.origin,manifest.origin);
assert.equal(authoring.functional_completed_through,"teacher-original-evidence");assert.equal(authoring.student_id,"10000000-0000-4000-8000-000000000002");
`+src.slice(end);
src=src.replace('  preparation,\n','  preparation,\n  prior_delivery:{report_sha256:hash(seamBytes),action_receipts:seam.mutations,no_mutation_replay:true},\n');
src=src.replace('  stage = "guard";','  stage = "guard";\nlet allowedStudentAction=null,displayAllowed=true;');
src=src.replace('  guard(expectedAction);','  assert.ok(["start","submit"].includes(expectedAction),"Only new student start/submit permitted in resumed phase");\n  assert.equal(path,"/api/student/interventions/"+seam.approval_id+"/followup");\n  allowedStudentAction=expectedAction;\n  guard(expectedAction);');
const functionsEnd=src.indexOf('async function contextCase(');assert.ok(functionsEnd>0);
const tail=src.slice(src.indexOf('} catch (error) {\n  report.status = mutationUncertain ?'));
src=src.slice(0,functionsEnd)+`
try {
  release=acquireLock({mode:"browser-intervention-resume-delivered",source:manifest.source,state,project:manifest.project,sourceSha:manifest.sourceSha});
  report.lock_owner=JSON.parse(readFileSync(resolve(LOCK_PATH,"owner.json"),"utf8"));await save();guard("browser-launch");
  browser=await chromium.launch({executablePath:process.env.BROWSER_EXECUTABLE,headless:true});
  const contexts=[await browser.newContext({viewport:{width:1440,height:1000}}),await browser.newContext({viewport:{width:1440,height:1000}})];
  const studentEndpoint="/api/student/interventions/"+seam.approval_id,followupEndpoint=studentEndpoint+"/followup";
  for(const [index,context] of contexts.entries()){
    let loginAllowed=true;
    await context.route("**/*",async route=>{
      const request=route.request(),url=new URL(request.url()),method=request.method();
      if(["data:","blob:"].includes(url.protocol))return route.continue();
      if(url.origin!==manifest.origin){report.blocked_off_origin_requests.push(url.href);return route.abort("blockedbyclient");}
      if(["GET","HEAD","OPTIONS"].includes(method))return route.continue();
      if(loginAllowed&&method==="POST"&&url.pathname==="/api/auth/demo-sign-in"){loginAllowed=false;return route.continue();}
      let body;try{body=request.postDataJSON();}catch{}
      if(index===1&&method==="POST"&&url.pathname===studentEndpoint&&body?.action==="displayed"&&displayAllowed){
        displayAllowed=false;mutationUncertain=true;report.display_acknowledgement={action:"displayed",approval_id:seam.approval_id,status:"outcome-unestablished",at:new Date().toISOString()};await save();return route.continue();
      }
      if(index===1&&method==="POST"&&url.pathname===followupEndpoint&&["start","submit"].includes(body?.action)&&body.action===allowedStudentAction){allowedStudentAction=null;return route.continue();}
      report.blocked_context_writes.push({url:url.href,method,action:body?.action??null});return route.abort("blockedbyclient");
    });
  }
  teacher=await contexts[0].newPage();student=await contexts[1].newPage();for(const p of [teacher,student])p.setDefaultTimeout(20000);
  await login(teacher,"teacher");await login(student,"student");
  stage="reconcile-acknowledged-delivery-and-not-started-followup";
  const endpoint="/api/teacher/interventions/"+preparation.draft_id;
  await teacher.goto(new URL(preparation.teacher_url,manifest.origin).href);
  const review=await read(contexts[0],endpoint);
  assert.equal(review.draft.id,preparation.draft_id);assert.equal(review.approval?.id,seam.approval_id);assert.equal(review.delivery?.id,seam.delivery_id);
  assert.equal(review.approval.draft_id,preparation.draft_id);assert.equal(review.delivery.approval_id,seam.approval_id);
  assert.deepEqual(review.approval.recipient_ids,[authoring.student_id]);assert.deepEqual(review.delivery.recipient_ids,[authoring.student_id]);
  assert.deepEqual(review.approval.content_ref,authoring.content_ref);assert.deepEqual(review.draft.evidence.content_ref,authoring.content_ref);
  assert.equal(review.draft.evidence.observations.find(o=>o.attempt.id===authoring.presented_attempt_id)?.attempt.response_text,authoring.original_response);
  const originalBefore=await read(contexts[0],"/api/teacher/sessions/"+authoring.student_session_id);
  const before=await read(contexts[1],followupEndpoint);assert.equal(before.approval_id,seam.approval_id);
  for(const key of ["started_at","attempt_id","submitted_at","response_text","evaluation_id"])assert.equal(before[key],null,"Already started/submitted: do not replay "+key);
  assert.equal(before.evaluation_status,"not_submitted");
  report.approval_id=seam.approval_id;report.delivery_id=seam.delivery_id;report.reconciled_before_followup=before;
  report.delivery_reconciled={draft_id:review.draft.id,approval_id:review.approval.id,delivery_id:review.delivery.id,recipient_ids:review.approval.recipient_ids,content_ref:review.approval.content_ref};await save();
  stage="same-student-opens-exact-acknowledged-review";
  await student.goto(new URL("/study/assignments",manifest.origin).href);
  const link=student.locator('article.lp-review-card a[href="/study/interventions/'+seam.approval_id+'"]');assert.equal(await link.count(),1);
  await link.click();await student.waitForURL("**/study/interventions/"+seam.approval_id);await student.locator(".lp-review-explanation").scrollIntoViewIfNeeded();
  const delivered=await read(contexts[1],studentEndpoint);assert.equal(delivered.approval_id,seam.approval_id);assert.deepEqual(delivered.content_ref,authoring.content_ref);
  assert.ok(!JSON.stringify(delivered).includes('"rubric"'));assert.ok(!JSON.stringify(delivered).includes('"answer_guidance"'));
  // The existing UI records assistance only when its explanation becomes visible.
  await student.waitForFunction(()=>document.querySelector('.lp-review-explanation')!==null);
  let observed=delivered;
  for(let i=0;i<5&&!observed.displayed_at;i++){await student.waitForTimeout(200);observed=await read(contexts[1],studentEndpoint);}
  assert.ok(observed.displayed_at,"Displayed acknowledgement must be reconciled before a fresh check");
  if(report.display_acknowledgement){report.display_acknowledgement.status="acknowledged-by-authorized-read";report.display_acknowledgement.displayed_at=observed.displayed_at;mutationUncertain=false;}
  await capture(student,"04-student-exact-delivered-review",true);
  const notStarted=await read(contexts[1],followupEndpoint);assert.deepEqual(notStarted,before);
  stage="same-student-starts-new-followup";
  await action(student,followupEndpoint,"start",()=>student.getByRole("button",{name:"Start fresh check",exact:true}).click());
  stage="same-student-submits-followup";await student.locator("#intervention-response").fill(preparation.followup_response);
  report.followup=await action(student,followupEndpoint,"submit",()=>student.getByRole("button",{name:"Submit fresh-check response",exact:true}).click());
  assert.equal(report.followup.response_text,preparation.followup_response);assert.equal(report.followup.evaluation_status,"failed");assert.ok(report.followup.submitted_at);
  await student.getByRole("heading",{name:"Evaluation failed",exact:true}).waitFor();await capture(student,"05-saved-followup-provider-disabled");
  stage="teacher-inspects-linked-provider-disabled-followup";
  report.comparison=await read(contexts[0],endpoint+"/followup");const linked=sameOriginal(report.comparison);
  assert.equal(linked.followup.response_text,preparation.followup_response);assert.equal(linked.followup.evaluation_status,"failed");
  await showTeacherComparison();await capture(teacher,"06-teacher-linked-provider-disabled-followup");
  const after=await read(contexts[0],endpoint);assert.deepEqual(after.approval,review.approval);assert.deepEqual(after.delivery,review.delivery);assert.deepEqual(after.draft,review.draft);
  assert.deepEqual(await read(contexts[0],"/api/teacher/sessions/"+authoring.student_session_id),originalBefore);
  assert.deepEqual(report.blocked_context_writes,[]);assert.deepEqual(report.mutations.map(m=>[m.action,m.http_status,m.status]),["start","submit"].map(a=>[a,200,"acknowledged"]));
  report.functional_completed_through="teacher-inspected-provider-disabled-followup";report.next_step="After normal retry_after, use explicit synthetic evaluation seam with this resumed receipt; never replay prior save/approve/deliver or new start/submit.";
  report.prior_approval_delivery_and_original_unchanged=true;report.status=report.screenshots.some(s=>s.overflow)?"failed-responsive":"passed";
`+tail;
src=src.replace('Usage: <review-and-submit|inspect-followup|context-checks|curated-activation>','Usage: <resume-delivered>');
const helper=join(bundle,'resume-delivered-browser.mjs');writeFileSync(helper,src,{flag:'wx'});
// Accept only this narrow truthful continuation in the later synthetic evaluator.
const fixturePath=join(bundle,'intervention-continuation-fixture.mjs'),fixtureBytes=readFileSync(fixturePath);copyFileSync(fixturePath,join(bundle,'intervention-continuation-fixture-v2-before-resume.mjs'),constants.COPYFILE_EXCL);
let fixture=fixtureBytes.toString();const old='    assert.equal(input.phase, "review-and-submit", "A new ordinary completed browser receipt is required; historical resumes are unsupported");';
assert.ok(fixture.includes(old));fixture=fixture.replace(old,`    if(input.phase==="resume-delivered"){
      assert.equal(input.prior_delivery?.report_sha256,"${failedHash}");assert.equal(input.prior_delivery.no_mutation_replay,true);
      assert.deepEqual(input.prior_delivery.action_receipts.map(m=>[m.action,m.http_status,m.status]),["save","approve","deliver"].map(a=>[a,200,"acknowledged"]));
      assert.deepEqual(input.mutations.map(m=>[m.action,m.http_status,m.status]),["start","submit"].map(a=>[a,200,"acknowledged"]));
      assert.equal(input.approval_id,"f187e046-fa5b-4f9d-bb3e-ddd1b457cee6");assert.equal(input.delivery_id,"91e360b9-7385-4453-a571-6aaf71e6840b");assert.equal(input.prior_approval_delivery_and_original_unchanged,true);
    }else assert.equal(input.phase,"review-and-submit","Require current ordinary or exact acknowledged-delivery continuation receipt");`);writeFileSync(fixturePath,fixture);
const provenance={status:'prepared-not-executed',at:new Date().toISOString(),failureReceiptSha256:failedHash,failureStage:failed.failure_stage,approvalId:failed.approval_id,deliveryId:failed.delivery_id,originalScriptPreserved:'journey-bundle/intervention-continuation-browser-v1-delivered-title-collision.mjs',originalScriptSha256:hash(original),resumeHelper:'journey-bundle/resume-delivered-browser.mjs',resumeHelperSha256:hash(readFileSync(helper)),priorFixturePreserved:'journey-bundle/intervention-continuation-fixture-v2-before-resume.mjs',priorFixtureSha256:hash(fixtureBytes),activeFixtureSha256:hash(readFileSync(fixturePath)),contract:'Exact acknowledged delivery reconciled by read; exact approval href; no teacher writes; ordinary display acknowledgement and only new start/submit; prior failure remains separate; no app changes'};
writeFileSync(join(root,'RESUME_DELIVERED_PROVENANCE.json'),JSON.stringify(provenance,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(provenance));
