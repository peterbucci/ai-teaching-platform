import { readFileSync,writeFileSync,readdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { join,dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import assert from 'node:assert/strict';
const root=dirname(fileURLToPath(import.meta.url)),hash=b=>createHash('sha256').update(b).digest('hex');
const file=join(root,'BROWSER_BUNDLE_PROVENANCE.json');const provenance=JSON.parse(readFileSync(file,'utf8'));
for(const item of provenance.files)item.preparedSha256=hash(readFileSync(join(root,item.destination)));
provenance.adaptations.push('Current tablet selector opens Evidence drawer and leaves Activity+Steps adjacent','Exact full original response disambiguates multiple before-records; no evidence assertion dropped');
const generated=['guarded-focused-browser.mjs','BROWSER_COMMANDS.txt','journey-bundle/r03-labels-browser.mjs','journey-bundle/inherited-fixture.json','visual-bundle/inherited-scenario.json','visual-bundle/focused-scenario.json','prepare-focused-visual.mjs'];
provenance.generatedFiles=generated.map(path=>({path,sha256:hash(readFileSync(join(root,path)))}));
provenance.syntaxChecks=[];
for(const dir of ['journey-bundle','visual-bundle'])for(const name of readdirSync(join(root,dir)).filter(n=>n.endsWith('.mjs'))){const path=join(dir,name),r=spawnSync(process.execPath,['--check',join(root,path)],{encoding:'utf8',windowsHide:true});provenance.syntaxChecks.push({path,exitCode:r.status});assert.equal(r.status,0,r.stderr);}
const r=spawnSync(process.execPath,['--check',join(root,'guarded-focused-browser.mjs')],{encoding:'utf8',windowsHide:true});assert.equal(r.status,0,r.stderr);provenance.syntaxChecks.push({path:'guarded-focused-browser.mjs',exitCode:r.status});
provenance.finalizedAt=new Date().toISOString();writeFileSync(file,JSON.stringify(provenance,null,2)+'\n');console.log(JSON.stringify({syntaxPassed:provenance.syntaxChecks.length,status:'prepared-not-executed'}));
